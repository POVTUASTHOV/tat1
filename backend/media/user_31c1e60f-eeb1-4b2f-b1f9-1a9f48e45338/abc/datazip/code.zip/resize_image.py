from PIL import Image
import os
import sys

def resize_image(input_path, output_path, target_width=1920, target_height=1080):
    image = Image.open(input_path)
    original_width, original_height = image.size
    
    target_aspect = target_width / target_height
    
    if original_width / original_height > target_aspect:
        new_height = original_height
        new_width = int(new_height * target_aspect)
        left = (original_width - new_width) // 2
        right = left + new_width
        cropped = image.crop((left, 0, right, original_height))
    else:
        new_width = original_width
        new_height = int(new_width / target_aspect)
        top = original_height - new_height
        bottom = original_height
        cropped = image.crop((0, top, original_width, bottom))
    
    resized = cropped.resize((target_width, target_height), Image.LANCZOS)
    resized.save(output_path)
    return True

def process_directory(directory_path):
    supported_formats = ('.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp')
    success_count = 0
    error_count = 0
    
    for filename in os.listdir(directory_path):
        file_path = os.path.join(directory_path, filename)
        
        if os.path.isfile(file_path) and filename.lower().endswith(supported_formats):
            try:
                if resize_image(file_path, file_path):
                    print(f"Successfully resized: {filename}")
                    success_count += 1
                else:
                    error_count += 1
            except Exception as e:
                print(f"Error processing {filename}: {e}")
                error_count += 1
    
    return success_count, error_count

if __name__ == "__main__":
    directory = r'D:\bai_toan\weapon\nen\a'
    
    if not os.path.exists(directory):
        print(f"Directory not found: {directory}")
        sys.exit(1)
    
    print(f"Processing images in: {directory}")
    success, errors = process_directory(directory)
    
    print("\nProcess completed!")
    print(f"Successfully resized: {success} images")
    print(f"Errors encountered: {errors} images")