import os
import json
import cv2
import numpy as np
import shutil
from pathlib import Path
from tqdm import tqdm
import uuid

class OBBToYOLOv8Converter:
    def __init__(self, input_dir, output_dir):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.class_map = {
            "person": 0,
            "gun": 1,
            "knife": 2,
            "stick": 3
        }
        self.image_extensions = [".jpg", ".jpeg", ".png", ".bmp"]
        
    def setup_directories(self):
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def get_file_pairs(self):
        file_pairs = []
        for file in self.input_dir.iterdir():
            if not file.is_file():
                continue
                
            if file.suffix.lower() not in self.image_extensions:
                continue
                
            json_path = file.with_suffix('.json')
            if json_path.exists():
                file_pairs.append((file, json_path))
        
        return file_pairs
    
    def fit_obb_to_points(self, points, img_width, img_height, json_path="unknown"):
        if len(points) < 2:
            return None
        
        points_array = np.array(points, dtype=np.float32)
        
        if np.any(np.isnan(points_array)) or np.all(points_array == points_array[0]):
            print(f"Invalid points in {json_path}: {points}")
            return None
        
        if len(points) >= 3:
            p1, p2 = points_array[0], points_array[-1]
            norm = np.linalg.norm(p2 - p1)
            if norm < 1e-6:
                return None
            distances = []
            for p in points_array:
                dist = np.abs(np.cross(p2 - p1, p - p1) / norm)
                distances.append(dist)
            
            if max(distances) < 5.0:
                center = np.mean(points_array, axis=0)
                length = np.linalg.norm(p2 - p1)
                width = 10.0
                angle = np.arctan2(p2[1] - p1[1], p2[0] - p1[0]) * 180 / np.pi
                rect = (center, (length, width), angle)
            else:
                rect = cv2.minAreaRect(points_array)
        else:
            center = np.mean(points_array, axis=0)
            length = np.linalg.norm(points_array[1] - points_array[0])
            width = 10.0
            angle = np.arctan2(points_array[1][1] - points_array[0][1], 
                             points_array[1][0] - points_array[0][0]) * 180 / np.pi
            rect = (center, (length, width), angle)
        
        if min(rect[1][0], rect[1][1]) < 1.0:
            print(f"Box too small in {json_path}: size {rect[1]}")
            return None
        
        box = cv2.boxPoints(rect)
        
        max_length = min(img_width, img_height) * 0.8
        if rect[1][0] > max_length or rect[1][1] > max_length:
            print(f"Resizing box in {json_path}: original size {rect[1]}")
            scale = max_length / max(rect[1][0], rect[1][1])
            new_size = (rect[1][0] * scale, rect[1][1] * scale)
            rect = (rect[0], new_size, rect[2])
            box = cv2.boxPoints(rect)
        
        result = []
        for point in box:
            x = max(0, min(float(point[0]), img_width - 1))
            y = max(0, min(float(point[1]), img_height - 1))
            result.append([x, y])
        
        return np.array(result)
    
    def convert_json_to_yolov8(self, json_path, img_path, output_txt_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            img_width = data.get("imageWidth", 0)
            img_height = data.get("imageHeight", 0)
            
            if img_width <= 0 or img_height <= 0:
                print(f"Invalid image size in {json_path}: {img_width}x{img_height}")
                return False
            
            yolo_lines = []
            
            for shape in data.get("shapes", []):
                label = shape.get("label", "").lower()
                shape_type = shape.get("shape_type", "")
                points = shape.get("points", [])
                
                if shape_type not in ["rectangle", "polygon"]:
                    print(f"Skipping shape_type {shape_type} in {json_path}")
                    continue
                
                if label not in self.class_map:
                    print(f"Unknown class {label} in {json_path}")
                    continue
                
                class_id = self.class_map[label]
                
                if shape_type == "rectangle" and len(points) == 2:
                    x1, y1 = points[0]
                    x2, y2 = points[1]
                    box_points = [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]
                    obb_points = self.fit_obb_to_points(box_points, img_width, img_height, json_path)
                else:
                    obb_points = self.fit_obb_to_points(points, img_width, img_height, json_path)
                
                if obb_points is None:
                    continue
                
                # Normalize coordinates
                normalized_points = obb_points / [img_width, img_height]
                
                # YOLOv8 OBB format: class_id x1 y1 x2 y2 x3 y3 x4 y4
                # Keep class_id as integer, coordinates as float
                coords = normalized_points.flatten().tolist()
                line = f"{class_id} " + " ".join(f"{x:.6f}" for x in coords)
                yolo_lines.append(line)
            
            if yolo_lines:
                with open(output_txt_path, 'w', encoding='utf-8') as f:
                    f.write("\n".join(yolo_lines))
                return True
            else:
                print(f"No valid annotations found in {json_path}")
                return False
                
        except Exception as e:
            print(f"Error processing {json_path}: {e}")
            return False
    
    def process_dataset(self):
        self.setup_directories()
        file_pairs = self.get_file_pairs()
        
        for img_path, json_path in tqdm(file_pairs, desc="Processing"):
            img_filename = img_path.name
            txt_filename = img_path.stem + '.txt'
            
            output_txt = self.output_dir / txt_filename
            output_img = self.output_dir / img_filename
            
            if self.convert_json_to_yolov8(json_path, img_path, output_txt):
                shutil.copy(img_path, output_img)
        
        processed_count = len(file_pairs)
        print(f"Processed {processed_count} files")
        print(f"Results saved to {self.output_dir}")
        

def main():
    input_dir = r"weapon/3_26/tong/obb/dataset/0356_augmented"
    output_dir = r"/media/tat/Learn1/bai_toan/weapon/3_26/tong/obb/dataset/0356_obb"
    converter = OBBToYOLOv8Converter(input_dir, output_dir)
    converter.process_dataset()

if __name__ == "__main__":
    main()