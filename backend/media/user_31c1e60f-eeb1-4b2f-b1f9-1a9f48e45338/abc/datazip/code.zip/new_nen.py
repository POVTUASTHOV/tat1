import json
import os
import numpy as np
from shapely.geometry import Polygon, box
from shapely import validation
from PIL import Image, ImageDraw
import random
import cv2
import glob

def load_json(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

def save_json(json_path, data):
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def shape_to_geometry(shape):
    points = shape["points"]
    shape_type = shape.get("shape_type", "polygon")
    if len(points) == 0:
        return None
    if shape_type == "rectangle":
        if len(points) >= 2:
            min_x = min(p[0] for p in points)
            min_y = min(p[1] for p in points)
            max_x = max(p[0] for p in points)
            max_y = max(p[1] for p in points)
            return box(min_x, min_y, max_x, max_y)
        else:
            return None
    if len(points) >= 3:
        try:
            closed_points = points + [points[0]] if points[0] != points[-1] else points
            poly = Polygon(closed_points)
            if not poly.is_valid:
                poly = poly.buffer(0)
            return poly if poly.is_valid else None
        except Exception:
            return None
    return None

def check_shapes_intersection(shape1, shape2):
    geom1 = shape_to_geometry(shape1)
    geom2 = shape_to_geometry(shape2)
    if geom1 is None or geom2 is None or not geom1.is_valid or not geom2.is_valid:
        return False
    try:
        return geom1.intersects(geom2) or geom1.touches(geom2)
    except Exception:
        return False

def get_bounding_box(shape):
    points = shape["points"]
    if not points:
        return None
    min_x = min(p[0] for p in points)
    min_y = min(p[1] for p in points)
    max_x = max(p[0] for p in points)
    max_y = max(p[1] for p in points)
    return min_x, min_y, max_x, max_y

def create_mask_from_shape(shape, img_size):
    mask = Image.new('L', img_size, 0)
    draw = ImageDraw.Draw(mask)
    points = shape["points"]
    shape_type = shape.get("shape_type", "polygon")
    if shape_type == "rectangle":
        min_x = min(p[0] for p in points)
        min_y = min(p[1] for p in points)
        max_x = max(p[0] for p in points)
        max_y = max(p[1] for p in points)
        draw.rectangle((min_x, min_y, max_x, max_y), fill=255)
    else:
        flat_points = [coord for point in points for coord in point]
        draw.polygon(flat_points, fill=255)
    return mask

def is_overlapping_with_existing_objects(paste_x, paste_y, new_width, new_height, existing_objects, margin=10):
    new_box = box(paste_x - margin, paste_y - margin, paste_x + new_width + margin, paste_y + new_height + margin)
    if not new_box.is_valid:
        return True
    for obj in existing_objects:
        if obj.is_valid and new_box.intersects(obj):
            return True
    return False

def get_random_position_in_pavement(pavement_bounds, new_width, new_height, img_width, img_height, pavement_geom, existing_objects, position_history):
    if not pavement_geom or not pavement_geom.is_valid:
        return None, None
    
    min_x, min_y, max_x, max_y = pavement_bounds
    pavement_width = max_x - min_x
    pavement_height = max_y - min_y
    safety_margin = 10
    extended_min_x = max(min_x - 0.2 * pavement_width, 0 + safety_margin)
    extended_max_x = min(max_x + 0.2 * pavement_width, img_width - new_width - safety_margin)
    extended_min_y = max(min_y, 0 + safety_margin)
    max_paste_y = min(max_y, img_height - new_height - safety_margin)
    
    grid_size = 5
    grid_x_step = (extended_max_x - extended_min_x) / grid_size if extended_max_x > extended_min_x else 1
    grid_y_step = (max_paste_y - extended_min_y) / grid_size if max_paste_y > extended_min_y else 1
    
    candidate_positions = []
    
    for i in range(grid_size):
        for j in range(grid_size):
            grid_x = extended_min_x + i * grid_x_step + random.uniform(-grid_x_step/2, grid_x_step/2)
            grid_y = extended_min_y + j * grid_y_step + random.uniform(-grid_y_step/2, grid_y_step/2)
            
            grid_x = max(extended_min_x, min(extended_max_x, grid_x))
            grid_y = max(extended_min_y, min(max_paste_y - new_height, grid_y))
            
            paste_x, paste_y = int(grid_x), int(grid_y)
            
            obj_box = box(paste_x, paste_y, paste_x + new_width, paste_y + new_height)
            if not obj_box.is_valid:
                continue
                
            try:
                intersection_area = pavement_geom.intersection(obj_box).area
                obj_area = obj_box.area
                if obj_area > 0 and intersection_area / obj_area >= 0.6 and not is_overlapping_with_existing_objects(paste_x, paste_y, new_width, new_height, existing_objects):
                    position_score = 0
                    for pos in position_history:
                        dist = ((paste_x - pos[0])**2 + (paste_y - pos[1])**2)**0.5
                        position_score += 1 / (dist + 1)
                    
                    position_distance_from_center = ((paste_x - (min_x + pavement_width/2))**2 + (paste_y - (min_y + pavement_height/2))**2)**0.5
                    position_score -= position_distance_from_center / 1000
                    
                    candidate_positions.append((paste_x, paste_y, position_score))
            except Exception:
                continue
    
    if candidate_positions:
        candidate_positions.sort(key=lambda x: x[2])
        return int(candidate_positions[0][0]), int(candidate_positions[0][1])
    
    for _ in range(20):
        paste_x = random.randint(int(extended_min_x), int(extended_max_x)) if extended_max_x > extended_min_x else int(extended_min_x)
        paste_y = random.randint(int(extended_min_y), int(max_paste_y - new_height)) if max_paste_y - new_height > extended_min_y else int(extended_min_y)
        
        obj_box = box(paste_x, paste_y, paste_x + new_width, paste_y + new_height)
        if not obj_box.is_valid:
            continue
            
        try:
            intersection_area = pavement_geom.intersection(obj_box).area
            obj_area = obj_box.area
            if obj_area > 0 and intersection_area / obj_box.area >= 0.6 and not is_overlapping_with_existing_objects(paste_x, paste_y, new_width, new_height, existing_objects):
                paste_x = int(min(max(paste_x, safety_margin), img_width - new_width - safety_margin))
                paste_y = int(min(max(paste_y, safety_margin), img_height - new_height - safety_margin))
                return paste_x, paste_y
        except Exception:
            continue
    
    paste_x = int(min(max(int(min_x), safety_margin), img_width - new_width - safety_margin))
    paste_y = int(min(max(int(min_y), safety_margin), img_height - new_height - safety_margin))
    return paste_x, paste_y

def calculate_perspective_scale(y_position, img_height, min_scale=0.5, max_scale=1.0):
    y_position = max(0, min(y_position, img_height))
    perspective_factor = (img_height - y_position) / img_height
    return min_scale + perspective_factor * (max_scale - min_scale)

def calculate_distance_from_camera(y_position, img_height):
    return (img_height - y_position) / img_height

def determine_object_scale(y_position, img_height, object_label, pavement_width, object_width):
    distance_factor = calculate_distance_from_camera(y_position, img_height)
    
    base_scale_multiplier = 1.0
    if object_label == "person":
        random_factor = random.uniform(0.9, 1.2)
        base_scale_multiplier = 1.5 * random_factor
    
    scale_range = {
        "person": (0.8, 1.6),
        "gun": (0.6, 1.2),
        "knife": (0.6, 1.2),
        "stick": (0.6, 1.2),
        "Abnormal": (0.6, 1.4)
    }
    
    min_scale, max_scale = scale_range.get(object_label, (0.6, 1.4))
    
    relative_object_size = object_width / pavement_width
    size_adjustment = min(max(1.0 - relative_object_size * 10, 0.8), 1.5)
    
    perspective_scale = min_scale + distance_factor * (max_scale - min_scale)
    adjusted_scale = perspective_scale * base_scale_multiplier * size_adjustment
    
    return max(min(adjusted_scale, max_scale * 1.5), min_scale * 0.8)

def process_image_pair(abnormal_img_path, abnormal_json_path, background_img_path, background_json_path, output_dir, position_history):
    background_data = load_json(background_json_path)
    abnormal_data = load_json(abnormal_json_path)
    
    pavement_shapes = [s for s in background_data["shapes"] if s["label"] == "pavement"]
    if not pavement_shapes:
        return False, position_history
    
    pavement_geom = shape_to_geometry(pavement_shapes[0])
    if pavement_geom is None or not pavement_geom.is_valid:
        return False, position_history
    
    pavement_bounds = pavement_geom.bounds
    img_height = background_data.get("imageHeight", 1080)
    img_width = background_data.get("imageWidth", 1920)
    pavement_width = pavement_bounds[2] - pavement_bounds[0]
    
    abnormal_shapes = [s for s in abnormal_data["shapes"] if s["label"] == "Abnormal"]
    if not abnormal_shapes:
        return False, position_history
    
    person_shapes = [s for s in background_data["shapes"] if s["label"] == "person"]
    existing_objects = []
    for shape in person_shapes:
        geom = shape_to_geometry(shape)
        if geom and geom.is_valid:
            existing_objects.append(geom)
    
    src_img = Image.open(abnormal_img_path).convert("RGBA")
    bg_img = Image.open(background_img_path).convert("RGBA")
    
    result_data = {
        "version": "0.4.16",
        "flags": {},
        "shapes": [],
        "imagePath": "",
        "imageData": None,
        "imageHeight": img_height,
        "imageWidth": img_width
    }
    
    result_data["shapes"].extend(person_shapes)
    new_shapes = []
    new_positions = []
    
    for abnormal_shape in abnormal_shapes:
        abnormal_bbox = get_bounding_box(abnormal_shape)
        if abnormal_bbox is None:
            continue
        
        src_min_x, src_min_y, src_max_x, src_max_y = abnormal_bbox
        src_width = src_max_x - src_min_x
        src_height = src_max_y - src_min_y
        
        mask = create_mask_from_shape(abnormal_shape, src_img.size)
        src_region = src_img.crop((int(src_min_x), int(src_min_y), int(src_max_x), int(src_max_y)))
        mask_region = mask.crop((int(src_min_x), int(src_min_y), int(src_max_x), int(src_max_y)))
        
        base_scale = min(pavement_width / src_width, 1.0) * 0.75
        
        temp_width = int(src_width * base_scale)
        temp_height = int(src_height * base_scale)
        
        paste_x, paste_y = get_random_position_in_pavement(pavement_bounds, temp_width, temp_height, 
                                                      img_width, img_height, pavement_geom, 
                                                      existing_objects, position_history)
        if paste_x is None or paste_y is None:
            continue
        
        person_scale_factor = random.uniform(0.9, 0.1)
        abnormal_scale = determine_object_scale(paste_y, img_height, "Abnormal", pavement_width, src_width)
        final_scale = base_scale * abnormal_scale * 1.4 * person_scale_factor
        
        new_width = int(src_width * final_scale)
        new_height = int(src_height * final_scale)
        
        # target_area_min = 15000
        # target_area_max = 25000
        target_area_min = 25000
        target_area_max = 35000
        current_area = new_width * new_height
        
        if current_area < target_area_min:
            scale_factor = (target_area_min / current_area) ** 0.5
            final_scale *= scale_factor
            new_width = int(src_width * final_scale)
            new_height = int(src_height * final_scale)
        elif current_area > target_area_max:
            scale_factor = (target_area_max / current_area) ** 0.5
            final_scale *= scale_factor
            new_width = int(src_width * final_scale)
            new_height = int(src_height * final_scale)
        
        new_width = min(new_width, img_width // 3)
        new_height = min(new_height, img_height // 2)
        
        src_region = src_region.resize((new_width, new_height), Image.Resampling.LANCZOS)
        mask_region = mask_region.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        paste_x, paste_y = get_random_position_in_pavement(pavement_bounds, new_width, new_height, 
                                                      img_width, img_height, pavement_geom, 
                                                      existing_objects, position_history)
        if paste_x is None or paste_y is None:
            continue
        
        new_positions.append((paste_x, paste_y))
        bg_img.paste(src_region, (int(paste_x), int(paste_y)), mask_region)
        
        existing_objects.append(box(paste_x, paste_y, paste_x + new_width, paste_y + new_height))
        
        related_objects = ["person", "gun", "knife", "stick"]
        related_shapes = [s for s in abnormal_data["shapes"] if s["label"] in related_objects and check_shapes_intersection(s, abnormal_shape)]
        
        person_shape = next((s for s in related_shapes if s["label"] == "person"), None)
        if person_shape and not any(s["label"] in ["gun", "knife", "stick"] for s in related_shapes):
            weapon_shapes = [s for s in abnormal_data["shapes"] if s["label"] in ["gun", "knife", "stick"]]
            if weapon_shapes:
                related_shapes.append(random.choice(weapon_shapes))
        
        person_final_scale = final_scale
        
        for source_shape in related_shapes:
            source_bbox = get_bounding_box(source_shape)
            if not source_bbox:
                continue
                
            src_obj_min_x, src_obj_min_y, src_obj_max_x, src_obj_max_y = source_bbox
            
            object_scale = person_final_scale if source_shape["label"] in ["gun", "knife", "stick"] else final_scale
            
            new_obj_points = []
            for x, y in source_shape["points"]:
                rel_x = (x - src_min_x) / src_width
                rel_y = (y - src_min_y) / src_height
                
                new_x = paste_x + (rel_x * new_width * object_scale / final_scale)
                new_y = paste_y + (rel_y * new_height * object_scale / final_scale)
                new_obj_points.append([new_x, new_y])
            
            new_obj_bbox = [
                min(p[0] for p in new_obj_points),
                min(p[1] for p in new_obj_points),
                max(p[0] for p in new_obj_points),
                max(p[1] for p in new_obj_points)
            ]
            
            if new_obj_bbox[2] <= new_obj_bbox[0] or new_obj_bbox[3] <= new_obj_bbox[1]:
                continue
                
            if (new_obj_bbox[0] < 0 or new_obj_bbox[2] >= img_width or 
                new_obj_bbox[1] < 0 or new_obj_bbox[3] >= img_height):
                
                x_shift = 0
                y_shift = 0
                
                margin = 5
                
                if new_obj_bbox[0] < 0:
                    x_shift = abs(new_obj_bbox[0]) + margin
                elif new_obj_bbox[2] >= img_width:
                    x_shift = -(new_obj_bbox[2] - img_width + margin)
                    
                if new_obj_bbox[1] < 0:
                    y_shift = abs(new_obj_bbox[1]) + margin
                elif new_obj_bbox[3] >= img_height:
                    y_shift = -(new_obj_bbox[3] - img_height + margin)
                
                adjusted_points = []
                for x, y in new_obj_points:
                    adjusted_points.append([x + x_shift, y + y_shift])
                
                new_obj_points = adjusted_points
                new_obj_bbox = [
                    min(p[0] for p in new_obj_points),
                    min(p[1] for p in new_obj_points),
                    max(p[0] for p in new_obj_points),
                    max(p[1] for p in new_obj_points)
                ]
                
                if (new_obj_bbox[0] < 0 or new_obj_bbox[2] >= img_width or 
                    new_obj_bbox[1] < 0 or new_obj_bbox[3] >= img_height):
                    continue
                
                if source_shape["label"] == "person" and (x_shift != 0 or y_shift != 0):
                    paste_x = int(paste_x + x_shift)
                    paste_y = int(paste_y + y_shift)
                    
                    bg_img.paste(src_region, (paste_x, paste_y), mask_region)
                    
                    existing_objects[-1] = box(paste_x, paste_y, paste_x + new_width, paste_y + new_height)
            
            new_shape = source_shape.copy()
            new_shape["points"] = new_obj_points
            new_shapes.append(new_shape)
    
    if not new_shapes:
        return False, position_history
    
    result_data["shapes"].extend(new_shapes)
    output_base_name = os.path.splitext(os.path.basename(abnormal_json_path))[0]
    bg_base_name = os.path.splitext(os.path.basename(background_img_path))[0]
    output_img_name = f"{output_base_name}_{bg_base_name}_combined.jpg"
    output_img_path = os.path.join(output_dir, output_img_name)
    
    bg_img.convert("RGB").save(output_img_path)
    result_data["imagePath"] = output_img_name
    result_data["imageHeight"] = bg_img.height
    result_data["imageWidth"] = bg_img.width
    
    output_json = os.path.join(output_dir, f"{output_base_name}_{bg_base_name}_combined.json")
    save_json(output_json, result_data)
    
    return True, position_history + new_positions

def main():
    background_dir = r"D:\bai_toan\weapon\nen"
    abnormal_dir = r"D:\bai_toan\weapon\13_4\tong\DJI_0382_W\DJI_0382_W\d"
    output_dir = r"D:\bai_toan\weapon\13_4\tong\DJI_0382_W\DJI_0382_W\d\new"
    
    os.makedirs(output_dir, exist_ok=True)
    
    background_images = glob.glob(os.path.join(background_dir, "*.jpg")) + glob.glob(os.path.join(background_dir, "*.png"))
    abnormal_images = glob.glob(os.path.join(abnormal_dir, "*.jpg")) + glob.glob(os.path.join(abnormal_dir, "*.png"))
    
    position_history_map = {}
    
    for abnormal_img_path in abnormal_images:
        abnormal_json_path = os.path.splitext(abnormal_img_path)[0] + ".json"
        if not os.path.exists(abnormal_json_path):
            continue
        
        abnormal_base_name = os.path.basename(abnormal_img_path)
        position_history = []
        
        for bg_img_path in background_images:
            bg_json_path = os.path.splitext(bg_img_path)[0] + ".json"
            if not os.path.exists(bg_json_path):
                continue
            
            bg_base_name = os.path.basename(bg_img_path)
            position_key = f"{abnormal_base_name}_{bg_base_name}"
            
            if position_key in position_history_map:
                position_history = position_history_map[position_key]
            
            success, updated_positions = process_image_pair(
                abnormal_img_path, 
                abnormal_json_path, 
                bg_img_path, 
                bg_json_path, 
                output_dir, 
                position_history
            )
            
            if success:
                position_history_map[position_key] = updated_positions
                position_history = updated_positions

if __name__ == "__main__":
    main()