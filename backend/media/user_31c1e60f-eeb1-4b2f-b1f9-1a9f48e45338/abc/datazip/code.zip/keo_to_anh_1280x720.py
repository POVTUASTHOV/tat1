import os
import json
import cv2
import numpy as np
import shutil
from pathlib import Path

def process_images_and_json(input_dir, output_dir, reference_image_path, problem_dir=None):
    """
    Xử lý ảnh và dữ liệu JSON annotation (bounding box hoặc segmentation polygon),
    tạo ảnh mới kích thước 1280x720 và điều chỉnh tọa độ annotation tương ứng.
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    if problem_dir:
        Path(problem_dir).mkdir(parents=True, exist_ok=True)
    
    reference_image = cv2.imread(reference_image_path)
    if reference_image is None:
        raise FileNotFoundError(f"Reference image not found: {reference_image_path}")
    
    target_width, target_height = 1280, 720
    
    image_files = [f for f in os.listdir(input_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    print(f"Found {len(image_files)} images to process")
    
    for idx, image_file in enumerate(image_files):
        try:
            if idx % 100 == 0:
                print(f"Processing image {idx}/{len(image_files)}")
                
            image_path = os.path.join(input_dir, image_file)
            image = cv2.imread(image_path)
            
            if image is None:
                print(f"Could not read image: {image_path}")
                continue
            
            height, width = image.shape[:2]
            json_file = os.path.splitext(image_file)[0] + '.json'
            json_path = os.path.join(input_dir, json_file)
            json_data = None
            bboxes = []
            polygons = []
            
            # Đọc dữ liệu JSON annotation
            if os.path.exists(json_path):
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        json_data = json.load(f)
                    
                    # Xử lý định dạng labelme và các định dạng khác
                    if 'shapes' in json_data:
                        for shape in json_data['shapes']:
                            if shape.get('shape_type') == 'rectangle' and 'points' in shape and len(shape['points']) >= 2:
                                points = shape['points']
                                x1, y1 = points[0]
                                x2, y2 = points[1]
                                x1, x2 = min(x1, x2), max(x1, x2)
                                y1, y2 = min(y1, y2), max(y1, y2)
                                bboxes.append({
                                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                    'id': shape.get('id', ''),
                                    'label': shape.get('label', '')
                                })
                            elif shape.get('shape_type') in ['polygon', 'mask'] and 'points' in shape and len(shape['points']) >= 3:
                                points = shape['points']
                                x_coords = [p[0] for p in points]
                                y_coords = [p[1] for p in points]
                                x1, y1 = min(x_coords), min(y_coords)
                                x2, y2 = max(x_coords), max(y_coords)
                                
                                polygons.append({
                                    'points': points,
                                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                    'id': shape.get('id', ''),
                                    'label': shape.get('label', '')
                                })
                                
                                # Thêm bounding box tương ứng để tính toán vị trí
                                bboxes.append({
                                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                    'id': shape.get('id', ''),
                                    'label': shape.get('label', '')
                                })
                    elif 'objects' in json_data:
                        for obj in json_data['objects']:
                            if 'bbox' in obj:
                                bbox = obj['bbox']
                                if len(bbox) == 4:
                                    if obj.get('format') == 'xyxy':
                                        x1, y1, x2, y2 = bbox
                                    else:
                                        x, y, w, h = bbox
                                        x1, y1, x2, y2 = x, y, x + w, y + h
                                    bboxes.append({
                                        'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                        'id': obj.get('id', ''),
                                        'class': obj.get('class', '')
                                    })
                            elif 'polygon' in obj:
                                poly_points = obj['polygon']
                                x_coords = [p[0] for p in poly_points]
                                y_coords = [p[1] for p in poly_points]
                                x1, y1 = min(x_coords), min(y_coords)
                                x2, y2 = max(x_coords), max(y_coords)
                                
                                polygons.append({
                                    'points': poly_points,
                                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                    'id': obj.get('id', ''),
                                    'class': obj.get('class', '')
                                })
                                
                                # Thêm bounding box tương ứng để tính toán vị trí
                                bboxes.append({
                                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                    'id': obj.get('id', ''),
                                    'class': obj.get('class', '')
                                })
                except Exception as e:
                    print(f"Error reading JSON {json_path}: {e}")
                    if problem_dir:
                        shutil.copy(image_path, os.path.join(problem_dir, image_file))
                        if os.path.exists(json_path):
                            shutil.copy(json_path, os.path.join(problem_dir, json_file))
                    continue
            
            # Khởi tạo ảnh mới với kích thước 1280x720
            new_image = np.zeros((target_height, target_width, 3), dtype=np.uint8)
            offset_x, offset_y = 0, 0
            
            # Trường hợp 1: Ảnh nhỏ hơn kích thước mục tiêu cả chiều rộng và cao
            if width <= target_width and height <= target_height:
                # Đặt ảnh vào giữa và điền phần nền bằng ảnh tham khảo
                padding_x = (target_width - width) // 2
                padding_y = (target_height - height) // 2
                
                new_image = cv2.resize(reference_image, (target_width, target_height))
                new_image[padding_y:padding_y+height, padding_x:padding_x+width] = image
                
                offset_x = padding_x
                offset_y = padding_y
            
            # Trường hợp 2: Ảnh rộng hơn kích thước mục tiêu nhưng chiều cao nhỏ hơn
            elif width > target_width and height <= target_height:
                if bboxes:
                    # Tìm vùng quan tâm dựa trên các bounding box
                    left = min(box['x1'] for box in bboxes)
                    right = max(box['x2'] for box in bboxes)
                    box_width = right - left
                    
                    if box_width <= target_width:
                        # Nếu tất cả bounding box vừa vặn trong khung hình mục tiêu
                        center_x = (left + right) / 2
                        start_x = max(0, int(center_x - target_width / 2))
                        if start_x + target_width > width:
                            start_x = width - target_width
                    else:
                        # Nếu bounding box rộng hơn khung hình mục tiêu
                        center_x = (left + right) / 2
                        start_x = int(center_x - target_width / 2)
                        start_x = max(0, min(start_x, width - target_width))
                        
                        # Kiểm tra nếu các đối tượng không đủ hiển thị
                        box_visible_ratio = target_width / box_width
                        if box_visible_ratio < 0.7 and problem_dir:
                            shutil.copy(image_path, os.path.join(problem_dir, image_file))
                            if os.path.exists(json_path):
                                shutil.copy(json_path, os.path.join(problem_dir, json_file))
                else:
                    # Nếu không có bounding box, cắt ở giữa
                    start_x = (width - target_width) // 2
                
                start_x = max(0, min(start_x, width - target_width))
                cropped = image[:, start_x:start_x + target_width]
                
                padding_y = (target_height - height) // 2
                new_image = cv2.resize(reference_image, (target_width, target_height))
                new_image[padding_y:padding_y+height, :] = cropped
                
                offset_x = -start_x
                offset_y = padding_y
            
            # Trường hợp 3: Ảnh cao hơn kích thước mục tiêu nhưng chiều rộng nhỏ hơn
            elif width <= target_width and height > target_height:
                if bboxes:
                    # Tìm vùng quan tâm dựa trên các bounding box
                    top = min(box['y1'] for box in bboxes)
                    bottom = max(box['y2'] for box in bboxes)
                    box_height = bottom - top
                    
                    if box_height <= target_height:
                        # Nếu tất cả bounding box vừa vặn trong khung hình mục tiêu
                        center_y = (top + bottom) / 2
                        start_y = max(0, int(center_y - target_height / 2))
                        if start_y + target_height > height:
                            start_y = height - target_height
                    else:
                        # Nếu bounding box cao hơn khung hình mục tiêu
                        center_y = (top + bottom) / 2
                        start_y = int(center_y - target_height / 2)
                        start_y = max(0, min(start_y, height - target_height))
                        
                        # Kiểm tra nếu các đối tượng không đủ hiển thị
                        box_visible_ratio = target_height / box_height
                        if box_visible_ratio < 0.7 and problem_dir:
                            shutil.copy(image_path, os.path.join(problem_dir, image_file))
                            if os.path.exists(json_path):
                                shutil.copy(json_path, os.path.join(problem_dir, json_file))
                else:
                    # Nếu không có bounding box, cắt ở giữa
                    start_y = (height - target_height) // 2
                
                start_y = max(0, min(start_y, height - target_height))
                cropped = image[start_y:start_y + target_height, :]
                
                padding_x = (target_width - width) // 2
                new_image = cv2.resize(reference_image, (target_width, target_height))
                new_image[:, padding_x:padding_x+width] = cropped
                
                offset_x = padding_x
                offset_y = -start_y
            
            # Trường hợp 4: Ảnh lớn hơn kích thước mục tiêu cả chiều rộng và cao
            else:
                if bboxes:
                    # Tìm vùng quan tâm dựa trên các bounding box
                    left = min(box['x1'] for box in bboxes)
                    right = max(box['x2'] for box in bboxes)
                    top = min(box['y1'] for box in bboxes)
                    bottom = max(box['y2'] for box in bboxes)
                    
                    box_width = right - left
                    box_height = bottom - top
                    
                    if box_width <= target_width and box_height <= target_height:
                        # Nếu tất cả bounding box vừa vặn trong khung hình mục tiêu
                        center_x = (left + right) / 2
                        center_y = (top + bottom) / 2
                        
                        start_x = max(0, int(center_x - target_width / 2))
                        start_y = max(0, int(center_y - target_height / 2))
                        
                        if start_x + target_width > width:
                            start_x = width - target_width
                        if start_y + target_height > height:
                            start_y = height - target_height
                    else:
                        # Nếu bounding box lớn hơn khung hình mục tiêu
                        center_x = (left + right) / 2
                        center_y = (top + bottom) / 2
                        
                        start_x = int(center_x - target_width / 2)
                        start_y = int(center_y - target_height / 2)
                        
                        start_x = max(0, min(start_x, width - target_width))
                        start_y = max(0, min(start_y, height - target_height))
                        
                        # Kiểm tra nếu các đối tượng không đủ hiển thị
                        visible_width = min(right, start_x + target_width) - max(left, start_x)
                        visible_height = min(bottom, start_y + target_height) - max(top, start_y)
                        
                        width_ratio = visible_width / box_width if box_width > 0 else 0
                        height_ratio = visible_height / box_height if box_height > 0 else 0
                        
                        if (width_ratio < 0.7 or height_ratio < 0.7) and problem_dir:
                            shutil.copy(image_path, os.path.join(problem_dir, image_file))
                            if os.path.exists(json_path):
                                shutil.copy(json_path, os.path.join(problem_dir, json_file))
                else:
                    # Nếu không có bounding box, cắt ở giữa
                    start_x = (width - target_width) // 2
                    start_y = (height - target_height) // 2
                
                start_x = max(0, min(start_x, width - target_width))
                start_y = max(0, min(start_y, height - target_height))
                
                cropped = image[start_y:start_y + target_height, start_x:start_x + target_width]
                new_image = cropped
                
                offset_x = -start_x
                offset_y = -start_y
            
            # Lưu ảnh mới
            output_image_path = os.path.join(output_dir, image_file)
            cv2.imwrite(output_image_path, new_image)
            
            # Cập nhật JSON với tọa độ mới
            if json_data and os.path.exists(json_path):
                # Xử lý định dạng labelme
                if 'shapes' in json_data:
                    updated_shapes = []
                    for shape in json_data['shapes']:
                        # Xử lý rectangle (bounding box)
                        if shape.get('shape_type') == 'rectangle' and 'points' in shape and len(shape['points']) >= 2:
                            points = shape['points']
                            x1, y1 = points[0]
                            x2, y2 = points[1]
                            
                            new_x1 = x1 + offset_x
                            new_y1 = y1 + offset_y
                            new_x2 = x2 + offset_x
                            new_y2 = y2 + offset_y
                            
                            # Kiểm tra xem bounding box có nằm trong ảnh mới không
                            if (new_x1 < target_width and new_y1 < target_height and 
                                new_x2 > 0 and new_y2 > 0):
                                # Điều chỉnh tọa độ để đảm bảo nằm trong ảnh
                                new_x1 = max(0, min(new_x1, target_width))
                                new_y1 = max(0, min(new_y1, target_height))
                                new_x2 = max(0, min(new_x2, target_width))
                                new_y2 = max(0, min(new_y2, target_height))
                                
                                if new_x2 > new_x1 and new_y2 > new_y1:
                                    shape['points'] = [[new_x1, new_y1], [new_x2, new_y2]]
                                    updated_shapes.append(shape)
                        
                        # Xử lý polygon
                        elif shape.get('shape_type') in ['polygon', 'mask'] and 'points' in shape and len(shape['points']) >= 3:
                            original_points = shape['points']
                            new_points = []
                            points_inside = 0
                            
                            for point in original_points:
                                new_x = point[0] + offset_x
                                new_y = point[1] + offset_y
                                
                                # Kiểm tra điểm có nằm trong ảnh không
                                if 0 <= new_x <= target_width and 0 <= new_y <= target_height:
                                    points_inside += 1
                                
                                # Điều chỉnh tọa độ để đảm bảo nằm trong ảnh
                                new_x = max(0, min(new_x, target_width))
                                new_y = max(0, min(new_y, target_height))
                                new_points.append([new_x, new_y])
                            
                            # Kiểm tra polygon có đủ điểm và có nằm trong ảnh không
                            if len(new_points) >= 3 and points_inside > 0:
                                # Thêm polygon đã điều chỉnh vào danh sách
                                shape['points'] = new_points
                                updated_shapes.append(shape)
                        else:
                            # Giữ nguyên các shape khác
                            updated_shapes.append(shape)
                    
                    json_data['shapes'] = updated_shapes
                    json_data['imagePath'] = image_file
                    json_data['imageWidth'] = target_width
                    json_data['imageHeight'] = target_height
                    json_data['imageData'] = None  # Không cần lưu imageData trong JSON
                
                # Xử lý định dạng objects
                elif 'objects' in json_data:
                    updated_objects = []
                    for obj in json_data['objects']:
                        # Xử lý bounding box
                        if 'bbox' in obj:
                            bbox = obj['bbox']
                            if len(bbox) == 4:
                                if obj.get('format') == 'xyxy':
                                    x1, y1, x2, y2 = bbox
                                    
                                    new_x1 = x1 + offset_x
                                    new_y1 = y1 + offset_y
                                    new_x2 = x2 + offset_x
                                    new_y2 = y2 + offset_y
                                    
                                    # Kiểm tra xem bounding box có nằm trong ảnh mới không
                                    if (new_x1 < target_width and new_y1 < target_height and 
                                        new_x2 > 0 and new_y2 > 0):
                                        # Điều chỉnh tọa độ để đảm bảo nằm trong ảnh
                                        new_x1 = max(0, min(new_x1, target_width))
                                        new_y1 = max(0, min(new_y1, target_height))
                                        new_x2 = max(0, min(new_x2, target_width))
                                        new_y2 = max(0, min(new_y2, target_height))
                                        
                                        if new_x2 > new_x1 and new_y2 > new_y1:
                                            obj['bbox'] = [new_x1, new_y1, new_x2, new_y2]
                                            updated_objects.append(obj)
                                else:
                                    # Định dạng xywh
                                    x, y, w, h = bbox
                                    
                                    new_x = x + offset_x
                                    new_y = y + offset_y
                                    
                                    # Kiểm tra xem bounding box có nằm trong ảnh mới không
                                    if (new_x < target_width and new_y < target_height and 
                                        new_x + w > 0 and new_y + h > 0):
                                        # Điều chỉnh tọa độ để đảm bảo nằm trong ảnh
                                        new_x = max(0, min(new_x, target_width - 1))
                                        new_y = max(0, min(new_y, target_height - 1))
                                        new_w = min(w, target_width - new_x)
                                        new_h = min(h, target_height - new_y)
                                        
                                        if new_w > 0 and new_h > 0:
                                            obj['bbox'] = [new_x, new_y, new_w, new_h]
                                            updated_objects.append(obj)
                        
                        # Xử lý polygon
                        elif 'polygon' in obj:
                            original_points = obj['polygon']
                            new_points = []
                            points_inside = 0
                            
                            for point in original_points:
                                new_x = point[0] + offset_x
                                new_y = point[1] + offset_y
                                
                                # Kiểm tra điểm có nằm trong ảnh không
                                if 0 <= new_x <= target_width and 0 <= new_y <= target_height:
                                    points_inside += 1
                                
                                # Điều chỉnh tọa độ để đảm bảo nằm trong ảnh
                                new_x = max(0, min(new_x, target_width))
                                new_y = max(0, min(new_y, target_height))
                                new_points.append([new_x, new_y])
                            
                            # Kiểm tra polygon có đủ điểm và có nằm trong ảnh không
                            if len(new_points) >= 3 and points_inside > 0:
                                obj['polygon'] = new_points
                                updated_objects.append(obj)
                        else:
                            # Giữ nguyên các object khác
                            updated_objects.append(obj)
                    
                    json_data['objects'] = updated_objects
                    if 'image' in json_data:
                        json_data['image'] = image_file
                
                # Cập nhật kích thước ảnh trong dữ liệu JSON
                if json_data.get('width'):
                    json_data['width'] = target_width
                if json_data.get('height'):
                    json_data['height'] = target_height
                
                # Lưu dữ liệu JSON mới
                output_json_path = os.path.join(output_dir, json_file)
                with open(output_json_path, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=4, ensure_ascii=False)
            
        except Exception as e:
            print(f"Error processing {image_file}: {e}")
            if problem_dir:
                try:
                    shutil.copy(image_path, os.path.join(problem_dir, image_file))
                    json_path = os.path.join(input_dir, os.path.splitext(image_file)[0] + '.json')
                    if os.path.exists(json_path):
                        shutil.copy(json_path, os.path.join(problem_dir, os.path.splitext(image_file)[0] + '.json'))
                except Exception as copy_error:
                    print(f"Error copying to problem directory: {copy_error}")
    
    print("Processing completed!")

if __name__ == "__main__":
    input_directory = "/media/tat/Learn1/bai_toan/30_4/TaiNan_Training/4_9_box"
    output_directory = "/media/tat/Learn1/bai_toan/30_4/TaiNan_Training/4_9_box_1280x720"
    reference_image = "/media/tat/Learn1/bai_toan/fire/IMG20250321160437.jpg"
    problem_directory = "/media/tat/Learn1/bai_toan/30_4/TaiNan_Training/4_9_box/problem_1280x720"
    
    process_images_and_json(input_directory, output_directory, reference_image, problem_directory)