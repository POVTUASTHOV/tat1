from PIL import Image
import os

image_paths = [
    "weapon/nen/26e5fe34-9fff-4102-a169-b6824f8cb87a.jpeg",
    "weapon/nen/45a8e84c-cf94-46c5-bc9d-f409ed91ffe4.jpeg",
    "weapon/nen/471c0ddb-471a-499e-8910-eb6da8cce176.jpeg",
    "weapon/nen/1763b32c-946b-4c8c-b385-736f2e8b2c6c.jpeg"
]

new_size = (1920, 1090)
output_dir = "weapon/nen_resized"
os.makedirs(output_dir, exist_ok=True)

for path in image_paths:
    img = Image.open(path)
    img_resized = img.resize(new_size, Image.Resampling.LANCZOS)

    filename = os.path.basename(path)
    output_path = os.path.join(output_dir, filename)
    img_resized.save(output_path)

print("Đã resize xong tất cả ảnh.")
