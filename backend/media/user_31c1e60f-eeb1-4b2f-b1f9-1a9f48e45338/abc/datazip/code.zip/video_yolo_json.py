import cv2
import os
import json
import ntpath
from ultralytics import YOLO
import numpy as np
from datetime import datetime

class VideoProcessor:
    def __init__(self, video_path, model_path):
        self.video_path = video_path
        self.video_name = ntpath.basename(video_path).split('.')[0]
        self.model = YOLO(model_path)
        self.output_dir = self.video_name
        os.makedirs(self.output_dir, exist_ok=True)
        
        self.cap = cv2.VideoCapture(video_path)
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.frame_count = 0
        self.saved_frames = 0
        
        self.class_names = {
            0: "person",
        }
    
    def process(self, interval=3, conf=0.55, iou=0.5, classes=[0], output_type="box"):
        seq_number = 1
        
        while self.cap.isOpened():
            success, frame = self.cap.read()
            
            if not success:
                break
                
            self.frame_count += 1
            
            if self.frame_count % interval == 0:
                frame = frame[180:180+720, 320:320+1280]
                results = self.model(frame, imgsz=1280, iou=iou, conf=conf, classes=classes)
                
                base_filename = f"{self.video_name}_{seq_number}"
                frame_filename = f"{base_filename}.jpg"
                json_filename = f"{base_filename}.json"
                
                frame_path = os.path.join(self.output_dir, frame_filename)
                json_path = os.path.join(self.output_dir, json_filename)
                
                cv2.imwrite(frame_path, frame)
                
                if output_type == "box":
                    self._process_box(results, frame_filename, json_path)
                elif output_type == "obb":
                    self._process_obb(results, frame_filename, json_path)
                elif output_type == "json":
                    self._process_json(results, frame_filename, json_path)
                elif output_type == "seg":
                    self._process_seg(results, frame_filename, json_path)
                
                annotated_frame = results[0].plot()
                cv2.imshow("YOLO Inference", annotated_frame)
                
                seq_number += 1
                self.saved_frames += 1
                
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
        
        self.cap.release()
        cv2.destroyAllWindows()
        
        return {
            "total_frames": self.frame_count,
            "saved_frames": self.saved_frames,
            "output_dir": self.output_dir,
            "output_type": output_type
        }
    
    def _process_box(self, results, frame_filename, json_path):
        labelme_json = {
            "version": "4.5.6",
            "flags": {},
            "shapes": [],
            "imagePath": frame_filename,
            "imageData": None,
            "imageHeight": self.height,
            "imageWidth": self.width
        }
        
        if len(results) > 0 and results[0].boxes is not None:
            boxes = results[0].boxes.xyxy.cpu().numpy()
            class_ids = results[0].boxes.cls.cpu().numpy()
            confidences = results[0].boxes.conf.cpu().numpy()
            
            for i in range(len(boxes)):
                box = boxes[i]
                class_id = int(class_ids[i])
                confidence = float(confidences[i])
                
                class_name = self.class_names.get(class_id, "unknown")
                
                points = [
                    [float(box[0]), float(box[1])],
                    [float(box[2]), float(box[3])]
                ]
                
                shape = {
                    "label": class_name,
                    "points": points,
                    "group_id": None,
                    "shape_type": "rectangle",
                    "flags": {}
                }
                
                labelme_json["shapes"].append(shape)
        
        with open(json_path, 'w') as f:
            json.dump(labelme_json, f, indent=2)
    
    def _process_obb(self, results, frame_filename, json_path):
        labelme_json = {
            "version": "4.5.6",
            "flags": {},
            "shapes": [],
            "imagePath": frame_filename,
            "imageData": None,
            "imageHeight": self.height,
            "imageWidth": self.width
        }
        
        if len(results) > 0 and hasattr(results[0], "obb") and results[0].obb is not None:
            obb_data = results[0].obb.data.cpu().numpy()
            class_ids = results[0].obb.cls.cpu().numpy()
            confidences = results[0].obb.conf.cpu().numpy()
            
            polygon_points = []
            for obb in obb_data:
                cx, cy, w, h, angle = obb[:5]
                points = self._get_rotated_box_points(cx, cy, w, h, angle)
                polygon_points.append(points)
            
            for i in range(len(obb_data)):
                class_id = int(class_ids[i])
                confidence = float(confidences[i])
                
                class_name = self.class_names.get(class_id, "unknown")
                
                points = polygon_points[i].tolist()
                
                shape = {
                    "label": class_name,
                    "points": points,
                    "group_id": None,
                    "shape_type": "polygon",
                    "flags": {}
                }
                
                labelme_json["shapes"].append(shape)
        
        with open(json_path, 'w') as f:
            json.dump(labelme_json, f, indent=2)
    
    def _process_json(self, results, frame_filename, json_path):
        output_json = {
            "image": frame_filename,
            "height": self.height,
            "width": self.width,
            "detections": []
        }
        
        if len(results) > 0 and results[0].boxes is not None:
            boxes = results[0].boxes.xyxy.cpu().numpy()
            class_ids = results[0].boxes.cls.cpu().numpy()
            confidences = results[0].boxes.conf.cpu().numpy()
            
            for i in range(len(boxes)):
                box = boxes[i]
                class_id = int(class_ids[i])
                confidence = float(confidences[i])
                
                class_name = self.class_names.get(class_id, "unknown")
                
                detection = {
                    "class_id": class_id,
                    "class_name": class_name,
                    "confidence": confidence,
                    "bbox": [float(box[0]), float(box[1]), float(box[2]), float(box[3])]
                }
                
                output_json["detections"].append(detection)
        
        with open(json_path, 'w') as f:
            json.dump(output_json, f, indent=2)
    
    def _process_seg(self, results, frame_filename, json_path):
        labelme_json = {
            "version": "4.5.6",
            "flags": {},
            "shapes": [],
            "imagePath": frame_filename,
            "imageData": None,
            "imageHeight": self.height,
            "imageWidth": self.width
        }
        
        if len(results) > 0 and hasattr(results[0], "masks") and results[0].masks is not None:
            masks = results[0].masks.xy
            class_ids = results[0].boxes.cls.cpu().numpy()
            confidences = results[0].boxes.conf.cpu().numpy()
            
            for i in range(len(masks)):
                mask = masks[i]
                class_id = int(class_ids[i])
                confidence = float(confidences[i])
                
                class_name = self.class_names.get(class_id, "unknown")
                
                points = []
                for point in mask:
                    points.append([float(point[0]), float(point[1])])
                
                shape = {
                    "label": class_name,
                    "points": points,
                    "group_id": None,
                    "shape_type": "polygon",
                    "flags": {}
                }
                
                labelme_json["shapes"].append(shape)
        
        with open(json_path, 'w') as f:
            json.dump(labelme_json, f, indent=2)
    
    def _get_rotated_box_points(self, cx, cy, w, h, angle):
        angle_rad = angle
        
        cos_a = np.cos(angle_rad)
        sin_a = np.sin(angle_rad)
        
        w2 = w / 2
        h2 = h / 2
        
        p1 = [cx - w2 * cos_a - h2 * sin_a, cy - w2 * sin_a + h2 * cos_a]
        p2 = [cx + w2 * cos_a - h2 * sin_a, cy + w2 * sin_a + h2 * cos_a]
        p3 = [cx + w2 * cos_a + h2 * sin_a, cy + w2 * sin_a - h2 * cos_a]
        p4 = [cx - w2 * cos_a + h2 * sin_a, cy - w2 * sin_a - h2 * cos_a]
        
        return np.array([p1, p2, p3, p4])

if __name__ == "__main__":
    video_path = "Traffic/4_9/DJI_0376_W.MP4"
    model_path = "/media/tat/Learn1/bai_toan/yolo11x-seg.pt"
    
    processor = VideoProcessor(video_path, model_path)
    output_type = "seg"  # Change to "box", "json", or "seg" based on model output
    results = processor.process(interval=3, conf=0.5, classes=[0, 2, 3], output_type=output_type)
    
    print(f"Processing complete. Total frames: {results['total_frames']}")
    print(f"Saved {results['saved_frames']} frames and annotations to {results['output_dir']}")