import cv2
import numpy as np
import os
import shutil
import random

def adjust_brightness(image, factor):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    
    # Điều chỉnh độ sáng với chuẩn hóa để tránh quá sáng
    v = np.clip(v.astype(np.float32) * factor, 0, 255).astype(np.uint8)
    if factor > 1:
        v = cv2.normalize(v, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    
    hsv = cv2.merge([h, s, v])
    result = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    
    return result

def process_images_in_folder(input_folder, output_folder, num_factors=1):
    # Tạo thư mục đầu ra nếu chưa tồn tại
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    # Các yếu tố điều chỉnh độ sáng và tên chỉ số
    brightness_factors = [
        (1.1, '11'), (1.15, '115'), (1.2, '12'), (1.25, '125'), (1.3, '13'),
        (0.7, '07'), (0.75, '075'), (0.8, '08'), (0.85, '085'), (0.9, '09')
    ]
    
    # Duyệt qua tất cả các file trong thư mục đầu vào
    for filename in os.listdir(input_folder):
        if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
            # Đọc ảnh
            image_path = os.path.join(input_folder, filename)
            original_image = cv2.imread(image_path)
            if original_image is None:
                print(f"Error: Could not read image {image_path}")
                continue
            
            # Tên file không có phần mở rộng
            base_name = os.path.splitext(filename)[0]
            # Tìm file nhãn .txt tương ứng
            txt_path = os.path.join(input_folder, base_name + '.txt')
            
            # Chọn ngẫu nhiên 1 yếu tố từ danh sách
            factor, factor_str = random.choice(brightness_factors)
            
            # Điều chỉnh độ sáng
            adjusted_image = adjust_brightness(original_image, factor)
            
            # Tạo tên file mới
            new_filename = f"{base_name}_{factor_str}.jpg"
            new_image_path = os.path.join(output_folder, new_filename)
            
            # Lưu ảnh đã điều chỉnh
            cv2.imwrite(new_image_path, adjusted_image)
            print(f"Saved adjusted image: {new_image_path}")
            
            # Sao chép file nhãn .txt nếu tồn tại
            if os.path.exists(txt_path):
                new_txt_filename = f"{base_name}_{factor_str}.txt"
                new_txt_path = os.path.join(output_folder, new_txt_filename)
                shutil.copy(txt_path, new_txt_path)
                print(f"Copied label: {new_txt_path}")

def main():
    input_folder = '/media/tat/Learn1/bai_toan/30_4/HungKHi_Training/a'
    output_folder = '/media/tat/Learn1/bai_toan/30_4/HungKHi_Training/a_adjusted'
    num_factors = 1  # Chỉ chọn 1 yếu tố độ sáng ngẫu nhiên cho mỗi ảnh
    
    process_images_in_folder(input_folder, output_folder, num_factors)

if __name__ == "__main__":
    main()