from ultralytics import YOLO

model = YOLO("30_4/HungKHi_Training/runs_v5/workspace/runs/segment/train2/weights/best.pt")  # pretrained YOLO11n model
results = model('30_4/aug/output/DJI_0356_W_0009_zoom_0_5.jpg',  iou=0.45, conf=0.1, imgsz=1280)

for result in results:
    result.show()