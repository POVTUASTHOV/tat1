from sahi.predict import get_sliced_prediction
from sahi import AutoDetectionModel
import cv2
import time

def run(view_img=False):
    detection_model = AutoDetectionModel.from_pretrained(
        model_type="ultralytics", model_path='yolo11s-seg.pt', confidence_threshold=0.4, device="cuda"
    )

    videocapture = cv2.VideoCapture("Traffic/video_v2/istockphoto-2187245911-640_adpp_is.mp4")
    frame_count = 0
    start_time = time.time()

    while videocapture.isOpened():
        success, frame = videocapture.read()
        if not success:
            break

        frame_count += 1
        if frame_count % 1 != 0:
            continue

        results = get_sliced_prediction(
            frame, detection_model, slice_height=216, slice_width=384, overlap_height_ratio=0.2, overlap_width_ratio=0.2
        )

        for prediction in results.object_prediction_list:
            x1, y1, x2, y2 = prediction.bbox.minx, prediction.bbox.miny, prediction.bbox.maxx, prediction.bbox.maxy
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (56, 56, 255), 2)
            label = prediction.category.name
            t_size = cv2.getTextSize(label, 0, fontScale=0.6, thickness=1)[0]
            cv2.rectangle(
                frame, (int(x1), int(y1) - t_size[1] - 3), (int(x1) + t_size[0], int(y1) + 3), (56, 56, 255), -1
            )
            cv2.putText(
                frame, label, (int(x1), int(y1) - 2), 0, 0.6, (255, 255, 255), thickness=1, lineType=cv2.LINE_AA
            )

        end_time = time.time()
        elapsed_time = end_time - start_time
        fps = frame_count / elapsed_time
        print(f"FPS: {fps}")

        cv2.putText(frame, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        if view_img:
            cv2.imshow("Webcam", frame)
            print(frame.shape)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    videocapture.release()
    cv2.destroyAllWindows()

run(view_img=True)