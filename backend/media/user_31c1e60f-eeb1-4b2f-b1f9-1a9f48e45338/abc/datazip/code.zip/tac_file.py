import os
import shutil
import glob

def get_image_files(directory):
    """Get all image files from a directory"""
    image_extensions = ['.jpg', '.jpeg', '.png', '.tif', '.tiff']
    image_files = []
    
    for ext in image_extensions:
        image_files.extend(glob.glob(os.path.join(directory, f'*{ext}')))
    
    return [os.path.basename(file) for file in image_files]

def copy_matching_files(source_dir, target_dir, matching_filenames):
    """Copy files from source to target if their base filename matches any in the list"""
    os.makedirs(target_dir, exist_ok=True)
    copied_count = 0
    
    for root, _, files in os.walk(source_dir):
        for file in files:
            file_base, file_ext = os.path.splitext(file)
            
            # Check if this is an image file that matches our list
            if file in matching_filenames:
                # Copy the image file
                src_path = os.path.join(root, file)
                dst_path = os.path.join(target_dir, file)
                shutil.copy2(src_path, dst_path)
                copied_count += 1
                
                # Look for corresponding txt file and copy if exists
                txt_file = file_base + '.txt'
                txt_src_path = os.path.join(root, txt_file)
                if os.path.exists(txt_src_path):
                    txt_dst_path = os.path.join(target_dir, txt_file)
                    shutil.copy2(txt_src_path, txt_dst_path)
                    copied_count += 1
    
    return copied_count

def main():
    # Define directories
    labeled_dir = r"D:\bai_toan\weapon\3_26\tong\DJI_0356_W_labeled\DJI_0356_W_labeled"
    train_dir = r"D:\bai_toan\weapon\3_26\tong\obb\dataset\train"
    val_dir = r"D:\bai_toan\weapon\3_26\tong\obb\dataset\val"
    output_dir = r"D:\bai_toan\weapon\3_26\tong\obb\dataset\0356"
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get list of image files in the labeled directory
    labeled_images = get_image_files(labeled_dir)
    print(f"Found {len(labeled_images)} images in labeled directory")
    
    # Copy matching files from train directory
    train_copied = copy_matching_files(train_dir, output_dir, labeled_images)
    print(f"Copied {train_copied} files from train directory")
    
    # Copy matching files from val directory
    val_copied = copy_matching_files(val_dir, output_dir, labeled_images)
    print(f"Copied {val_copied} files from val directory")
    
    print(f"Total files copied to {output_dir}: {train_copied + val_copied}")

if __name__ == "__main__":
    main()