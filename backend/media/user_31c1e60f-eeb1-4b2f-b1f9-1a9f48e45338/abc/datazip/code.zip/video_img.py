import cv2
import os
import ntpath
from datetime import datetime

class VideoProcessor:
    def __init__(self, video_path):
        self.video_path = video_path
        self.video_name = ntpath.basename(video_path).split('.')[0]
        self.output_dir = self.video_name
        os.makedirs(self.output_dir, exist_ok=True)
        
        self.cap = cv2.VideoCapture(video_path)
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.frame_count = 0
        self.saved_frames = 0
    
    def process(self, interval=3):
        seq_number = 1
        
        while self.cap.isOpened():
            success, frame = self.cap.read()
            
            if not success:
                break
                
            self.frame_count += 1
            
            if self.frame_count % interval == 0:
                base_filename = f"{self.video_name}_{seq_number}"
                frame_filename = f"{base_filename}.jpg"
                
                frame_path = os.path.join(self.output_dir, frame_filename)
                
                cv2.imwrite(frame_path, frame)
                
                cv2.imshow("Frame", frame)
                
                seq_number += 1
                self.saved_frames += 1
                
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
        
        self.cap.release()
        cv2.destroyAllWindows()
        
        return {
            "total_frames": self.frame_count,
            "saved_frames": self.saved_frames,
            "output_dir": self.output_dir
        }

if __name__ == "__main__":
    video_path = r"D:\bai_toan\check_13_4_sai\data_13042025\DJI_0390_W.MP4"
    
    processor = VideoProcessor(video_path)
    results = processor.process(interval=3)
    
    print(f"Processing complete. Total frames: {results['total_frames']}")
    print(f"Saved {results['saved_frames']} frames to {results['output_dir']}")