import os
import json
from pathlib import Path
from tqdm import tqdm

def convert_box_to_segmentation(points):
    """Chuyển đổi box (2 điểm) thành segmentation (4 điểm)"""
    if len(points) != 2:
        return points  # Nếu không phải 2 điểm, giữ nguyên
    
    # Lấy các tọa độ từ 2 điểm góc đối diện
    x1, y1 = points[0]
    x2, y2 = points[1]
    
    # Tạo 4 điểm góc của box (theo thứ tự: trên-trái, trên-phải, dưới-phải, dưới-trái)
    return [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]

def update_json_files(input_dir):
    """Cập nhật trực tiếp các file JSON LabelMe để chuyển box thành segmentation"""
    input_dir_path = Path(input_dir)
    
    # Tìm tất cả các file JSON trong thư mục
    json_files = list(input_dir_path.glob('**/*.json'))
    print(f"Tìm thấy {len(json_files)} file JSON để cập nhật")
    
    # Thống kê
    stats = {
        "total_files": len(json_files),
        "updated_files": 0,
        "updated_annotations": 0,
        "unchanged_files": 0
    }
    
    # Xử lý từng file JSON
    for json_file in tqdm(json_files, desc="Đang cập nhật file JSON"):
        try:
            # Đọc file JSON
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            file_updated = False
            
            # Kiểm tra và cập nhật từng shape
            for shape in data.get("shapes", []):
                points = shape.get("points", [])
                shape_type = shape.get("shape_type", "").lower()
                
                # Chỉ cập nhật hình chữ nhật hoặc box với đúng 2 điểm
                if (shape_type == "rectangle" or len(points) == 2) and shape_type != "polygon":
                    # Chuyển đổi thành 4 điểm
                    shape["points"] = convert_box_to_segmentation(points)
                    
                    # Đánh dấu kiểu shape là polygon
                    shape["shape_type"] = "polygon"
                    
                    file_updated = True
                    stats["updated_annotations"] += 1
            
            # Lưu lại file JSON nếu có thay đổi
            if file_updated:
                with open(json_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
                stats["updated_files"] += 1
            else:
                stats["unchanged_files"] += 1
                
        except Exception as e:
            print(f"Lỗi khi xử lý file {json_file}: {e}")
    
    # In thống kê
    print("\n===== THỐNG KÊ XỬ LÝ =====")
    print(f"Tổng số file JSON: {stats['total_files']}")
    print(f"Số file đã cập nhật: {stats['updated_files']}")
    print(f"Số file không thay đổi: {stats['unchanged_files']}")
    print(f"Tổng số chú thích đã cập nhật: {stats['updated_annotations']}")
    print("============================")

if __name__ == "__main__":
    input_dir = "30_4/TaiNan_Training/tong"  # Thay đổi đường dẫn tại đây
    update_json_files(input_dir)
    print("Đã cập nhật xong tất cả file JSON!")