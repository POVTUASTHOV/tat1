import os
import json
import numpy as np
from collections import Counter

def calculate_sides_and_angles(points):
    sides = []
    angles = []
    
    n = len(points)
    for i in range(n):
        p1 = np.array(points[i])
        p2 = np.array(points[(i+1) % n])
        side = np.linalg.norm(p2 - p1)
        sides.append(side)
    
    for i in range(n):
        p1 = np.array(points[(i-1) % n])
        p2 = np.array(points[i])
        p3 = np.array(points[(i+1) % n])
        
        v1 = p1 - p2
        v2 = p3 - p2
        
        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        cos_angle = dot_product / (norm_v1 * norm_v2)
        cos_angle = max(min(cos_angle, 1.0), -1.0)
        angle = np.arccos(cos_angle) * 180.0 / np.pi
        angles.append(angle)
    
    return sides, angles

def is_rectangle(points, tolerance=5.0):
    if len(points) != 4:
        return False
    
    sides, angles = calculate_sides_and_angles(points)
    
    for angle in angles:
        if abs(angle - 90) > tolerance:
            return False
    
    return True

def detect_label_types():
    input_dir = "/media/tat/Learn1/bai_toan/30_4/TaiNan_Training/tong"
    
    label_types = []
    class_counts = Counter()
    
    for filename in os.listdir(input_dir):
        if filename.endswith('.json'):
            file_path = os.path.join(input_dir, filename)
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                for shape in data.get('shapes', []):
                    shape_type = shape.get('shape_type', '')
                    label = shape.get('label', '')
                    
                    if shape_type == 'polygon':
                        points = shape.get('points', [])
                        if len(points) == 4:
                            if is_rectangle(points):
                                label_types.append('obb')
                            else:
                                label_types.append('segmentation')
                        else:
                            label_types.append('segmentation')
                    elif shape_type == 'rectangle':
                        label_types.append('box')
                    else:
                        label_types.append(shape_type)
                    
                    class_counts[label] += 1
            except Exception as e:
                print(f"Lỗi khi xử lý {filename}: {str(e)}")
    
    label_type_counts = Counter(label_types)
    
    print("Các loại nhãn được phát hiện:")
    for label_type, count in label_type_counts.items():
        print(f"- {label_type}: {count} chú thích")
    
    print("\nCác lớp được phát hiện:")
    for class_name, count in class_counts.items():
        print(f"- {class_name}: {count} chú thích")
    
    if len(label_types) == 0:
        print("Không có file JSON nào chứa nhãn được tìm thấy trong thư mục.")

if __name__ == "__main__":
    detect_label_types()