import os
import json
import glob

folder_path = r"D:\bai_toan\weapon\13_4\tong\DJI_0380_W_3_labeled\DJI_0380_W_3_labeled"

all_files = os.listdir(folder_path)

image_files = [f for f in all_files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
json_files = [f for f in all_files if f.lower().endswith('.json')]

image_bases = [os.path.splitext(f)[0] for f in image_files]
json_bases = [os.path.splitext(f)[0] for f in json_files]

files_to_delete = []

for img in image_files:
    base_name = os.path.splitext(img)[0]
    if base_name not in json_bases:
        files_to_delete.append(img)

for js in json_files:
    base_name = os.path.splitext(js)[0]
    if base_name not in image_bases:
        files_to_delete.append(js)

target_labels = ['gun', 'knife', 'stick']
for js in json_files:
    base_name = os.path.splitext(js)[0]
    
    if js in files_to_delete:
        continue
    
    try:
        with open(os.path.join(folder_path, js), 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        labels = [shape.get('label', '') for shape in data.get('shapes', [])]
        
        if not any(label in target_labels for label in labels):
            files_to_delete.append(js)
            for ext in ['.jpg', '.jpeg', '.png']:
                img_file = base_name + ext
                if img_file in image_files:
                    files_to_delete.append(img_file)
    except:
        files_to_delete.append(js)
        for ext in ['.jpg', '.jpeg', '.png']:
            img_file = base_name + ext
            if img_file in image_files:
                files_to_delete.append(img_file)

print(f"Tổng số file sẽ bị xóa: {len(files_to_delete)}")
for f in files_to_delete:
    file_path = os.path.join(folder_path, f)
    try:
        os.remove(file_path)
        print(f"Đã xóa: {f}")
    except Exception as e:
        print(f"Không thể xóa {f}: {e}")

print("Hoàn tất xóa file.")