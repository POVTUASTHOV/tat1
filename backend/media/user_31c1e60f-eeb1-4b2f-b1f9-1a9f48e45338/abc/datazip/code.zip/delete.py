import os
import glob
from IPython.display import display, HTML

class FileDeleter:
    def __init__(self, directory_path):
        self.directory_path = directory_path
        
    def validate_directory(self):
        if not os.path.exists(self.directory_path):
            print(f"Directory {self.directory_path} does not exist.")
            return False
        
        if not os.path.isdir(self.directory_path):
            print(f"{self.directory_path} is not a directory.")
            return False
            
        return True
        
    def delete_files(self, extension):
        if not self.validate_directory():
            return False
        
        if not extension.startswith('.'):
            extension = '.' + extension
            
        file_pattern = os.path.join(self.directory_path, f"*{extension}")
        files_to_delete = glob.glob(file_pattern)
        
        if not files_to_delete:
            print(f"No {extension} files found in {self.directory_path}.")
            return True
        
        deleted_count = 0
        for file_path in files_to_delete:
            try:
                os.remove(file_path)
                deleted_count += 1
            except OSError as e:
                print(f"Error deleting {file_path}: {e}")
        
        print(f"Successfully deleted {deleted_count}{extension} files from {self.directory_path}.")
        return True

# Example usage in Jupyter Notebook
directory_path = "/media/tat/Learn1/bai_toan/Traffic/4_9/nhan/DJI_0372_W"
extension = "json"  # Change to json, jpg, or other extensions as needed

deleter = FileDeleter(directory_path)
deleter.delete_files(extension)