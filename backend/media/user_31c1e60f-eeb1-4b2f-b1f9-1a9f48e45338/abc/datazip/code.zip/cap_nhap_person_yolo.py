import os
import json
import glob
from ultralytics import YOLO
from pathlib import Path
import numpy as np

def update_person_annotations(json_file, model):
    # Load the JSON file
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # Get the corresponding image path
    img_filename = data['imagePath']
    directory = os.path.dirname(json_file)
    img_path = os.path.join(directory, os.path.basename(img_filename))
    
    # Check if image exists
    if not os.path.exists(img_path):
        # Try to find the image with different extensions
        base_name = os.path.splitext(os.path.basename(img_filename))[0]
        for ext in ['.jpg', '.jpeg', '.png']:
            potential_path = os.path.join(directory, base_name + ext)
            if os.path.exists(potential_path):
                img_path = potential_path
                break
        else:
            print(f"Image not found for {json_file}")
            return
    
    # Remove all person annotations
    data['shapes'] = [shape for shape in data['shapes'] if shape['label'] != 'person']
    
    # Run YOLO detection
    results = model(img_path, classes=[0], iou=0.45, conf=0.5, imgsz=1280)
    
    # Add new person annotations from YOLO results
    for result in results:
        boxes = result.boxes
        
        for i, box in enumerate(boxes):
            if box.cls == 0:  # Class 0 is person in COCO dataset
                xywh = box.xywh[0].tolist()
                x_center, y_center, width, height = xywh
                
                # Calculate rectangle points
                x1 = max(0, x_center - width/2)
                y1 = max(0, y_center - height/2)
                x2 = min(data['imageWidth'], x_center + width/2)
                y2 = min(data['imageHeight'], y_center + height/2)
                
                # Create labelme shape
                new_shape = {
                    "label": "person",
                    "points": [[x1, y1], [x2, y2]],
                    "group_id": None,
                    "shape_type": "rectangle",
                    "flags": {}
                }
                
                data['shapes'].append(new_shape)
    
    # Save the updated JSON file
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    print(f"Updated {json_file}")

def process_directory(directory_path, model_path):
    # Load YOLO model
    model = YOLO(model_path)
    
    # Get all JSON files in the directory
    json_files = glob.glob(os.path.join(directory_path, "*.json"))
    print(f"Found {len(json_files)} JSON files to process")
    
    # Process each JSON file
    for json_file in json_files:
        update_person_annotations(json_file, model)

if __name__ == "__main__":
    directory_path = "/media/tat/Learn1/bai_toan/weapon/3_26/tong/obb/dataset/0356"
    model_path = "yolo12s.pt"
    
    process_directory(directory_path, model_path)