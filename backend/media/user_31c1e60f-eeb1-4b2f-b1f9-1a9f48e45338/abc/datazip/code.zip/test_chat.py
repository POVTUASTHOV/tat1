import os
import tensorflow as tf
from tensorflow import keras
import sentencepiece as spm
import numpy as np

# Đường dẫn đến thư mục chứa mô hình Gemma 2
MODEL_PATH = "/media/tat/Learn1/bai_toan/chat_bot"

def load_model():
    """Load mô hình Gemma 2 từ các file đã giải nén"""
    # Tải mô hình từ file weights và config
    model = keras.models.load_model(MODEL_PATH)
    print("Đã tải mô hình thành công!")
    return model

def load_tokenizer():
    """Load và cài đặt tokenizer cho mô hình Gemma 2"""
    vocab_path = os.path.join(MODEL_PATH, "assets/tokenizer/vocabulary.spm")
    
    # Tạo tokenizer từ vocabulary.spm
    sp_model = spm.SentencePieceProcessor()
    sp_model.load(vocab_path)
    
    return sp_model

def generate_text(prompt, model, tokenizer, max_length=100, temperature=0.7):
    """Tạo văn bản từ prompt sử dụng mô hình Gemma 2"""
    # Chuẩn bị prompt theo format của Gemma 2
    input_prompt = f"<start_of_turn>user\n{prompt}<end_of_turn>\n<start_of_turn>model\n"
    
    # Tokenize prompt
    input_ids = tokenizer.encode(input_prompt)
    input_ids = tf.convert_to_tensor([input_ids], dtype=tf.int32)
    
    # Tạo attention mask (tất cả là 1 vì không có padding)
    attention_mask = tf.ones_like(input_ids, dtype=tf.int32)
    
    # Tạo văn bản
    generated_text = ""
    for _ in range(max_length):
        # Truyền cả input_ids và attention_mask vào model
        predictions = model([input_ids, attention_mask])
        
        # Lấy logits của token cuối cùng
        if isinstance(predictions, list):
            logits = predictions[0]  # Nếu model trả về nhiều đầu ra
        else:
            logits = predictions
            
        next_token_logits = logits[0, -1, :]
        
        # Áp dụng temperature sampling
        next_token_logits = next_token_logits / temperature
        next_token = tf.random.categorical(tf.expand_dims(next_token_logits, 0), 1)[0, 0].numpy()
        
        # Thêm token mới vào input
        input_ids = tf.concat([input_ids, tf.convert_to_tensor([[next_token]], dtype=tf.int32)], axis=1)
        # Cập nhật attention mask
        attention_mask = tf.ones_like(input_ids, dtype=tf.int32)
        
        # Decode token mới
        token_text = tokenizer.decode([next_token])
        generated_text += token_text
        
        # Kiểm tra điều kiện dừng (token EOS hoặc END)
        if "<end_of_turn>" in token_text:
            break
    
    return generated_text

def chat_with_gemma():
    """Hàm trò chuyện với Gemma 2 model"""
    model = load_model()
    tokenizer = load_tokenizer()
    
    print("=== Chào mừng đến với Gemma 2 Chat Bot ===")
    print("Nhập 'exit' để thoát")
    
    while True:
        user_input = input("\nBạn: ")
        if user_input.lower() == 'exit':
            break
        
        try:
            response = generate_text(user_input, model, tokenizer)
            print(f"Gemma: {response}")
        except Exception as e:
            print(f"Lỗi: {e}")
            # In thêm thông tin debug
            print("\nThông tin debug:")
            print(f"Model input shapes: {model.input_shape}")
            print(f"Model expects inputs: {[input.name for input in model.inputs]}")

def inspect_model():
    """Hàm kiểm tra cấu trúc mô hình để debug"""
    model = load_model()
    print("\n=== Thông tin mô hình ===")
    print(f"Input shapes: {model.input_shape}")
    print(f"Input names: {[input.name for input in model.inputs]}")
    print(f"Output shapes: {model.output_shape}")
    
    # In summary của model
    print("\n=== Model Summary ===")
    model.summary()
    
    return model

if __name__ == "__main__":
    # Cấu hình GPU
    physical_devices = tf.config.list_physical_devices('GPU')
    if physical_devices:
        print(f"Tìm thấy {len(physical_devices)} GPU")
        try:
            # Cấu hình GPU để sử dụng memory growth
            for device in physical_devices:
                tf.config.experimental.set_memory_growth(device, True)
            print("Đã cấu hình GPU memory growth")
        except Exception as e:
            print(f"Không thể cấu hình GPU: {e}")
    else:
        print("WARNING: Không tìm thấy GPU. Mô hình sẽ chạy trên CPU (có thể rất chậm).")
    
    # Chạy hàm kiểm tra mô hình trước
    model = inspect_model()
    
    # Sau đó mới chạy chat
    chat_with_gemma()