from sahi.predict import get_sliced_prediction
from sahi import AutoDetectionModel
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

detection_model = AutoDetectionModel.from_pretrained(
    model_type="ultralytics",
    model_path="30_4/HungKHi_Training/runs_v5/workspace/runs/segment/train2/weights/best.pt",
    confidence_threshold=0.3,
    device='cuda:0'
)

result = get_sliced_prediction(
    "30_4/aug/output/DJI_0410_W_4162_zoom_0_4.jpg",
    detection_model,
    slice_height=256,
    slice_width=256,
    overlap_height_ratio=0.2,
    overlap_width_ratio=0.2
)

img = plt.imread("30_4/aug/output/DJI_0410_W_4162_zoom_0_4.jpg")

fig, ax = plt.subplots()
ax.imshow(img)

for prediction in result.object_prediction_list:
    bbox = prediction.bbox
    x1, y1, x2, y2 = bbox.minx, bbox.miny, bbox.maxx, bbox.maxy
    w, h = x2 - x1, y2 - y1
    rect = Rectangle((x1, y1), w, h, linewidth=2, edgecolor=(1, 0.22, 0.22), facecolor='none')
    ax.add_patch(rect)
    
    label = prediction.category.name
    text_obj = ax.text(0, 0, label, fontsize=8, color='white')
    bbox_obj = text_obj.get_window_extent(renderer=fig.canvas.get_renderer())
    text_width = bbox_obj.width / 100
    text_height = bbox_obj.height / 100
    text_obj.remove()
    
    label_rect = Rectangle((x1, y1 - text_height - 3), text_width, text_height + 3, 
                          edgecolor='none', facecolor=(1, 0.22, 0.22))
    ax.add_patch(label_rect)
    
    ax.text(x1, y1 - 2, label, color='white', fontsize=8)

plt.show()