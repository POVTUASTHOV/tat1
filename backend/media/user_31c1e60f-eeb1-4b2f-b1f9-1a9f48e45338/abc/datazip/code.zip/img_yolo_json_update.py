import os
import json
import cv2
import numpy as np
from ultralytics import YOLO
from pathlib import Path

# Cấu hình
image_folder = "30_4/HungKHi_Training/0356/cach"
model_path = "/media/tat/Learn1/bai_toan/yolo11x-seg.pt"
conf_threshold = 0.5
iou_threshold = 0.5
imgsz = 1280
classes = [0]  # Chỉ phát hiện class "person"

# Load model YOLO
model = YOLO(model_path)

# Hàm chuyển đổi mask sang định dạng LabelMe (danh sách điểm)
def mask_to_labelme_points(mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    points = []
    for contour in contours:
        if len(contour) >= 3:  # Chỉ lấy contour có ít nhất 3 điểm
            contour = contour.squeeze(1).tolist()
            points.append(contour)
    return points

# Hàm tạo hoặc cập nhật file JSON
def create_or_update_json(image_path, json_path, detections, image_height, image_width):
    # Template cơ bản cho file JSON LabelMe
    json_data = {
        "version": "5.2.1",
        "flags": {},
        "shapes": [],
        "imagePath": os.path.basename(image_path),
        "imageData": None,
        "imageHeight": image_height,
        "imageWidth": image_width
    }

    # Nếu file JSON đã tồn tại, đọc nội dung
    if os.path.exists(json_path):
        with open(json_path, 'r') as f:
            json_data = json.load(f)
        print(f"Đọc file JSON tồn tại: {json_path}")
    else:
        print(f"Tạo mới file JSON: {json_path}")

    # Lấy danh sách nhãn hiện có
    existing_labels = [shape["label"] for shape in json_data["shapes"]]

    # Thêm nhãn "person" từ YOLO nếu chưa có
    for det in detections:
        if det["class"] == "person":
            if "person" not in existing_labels:  # Chỉ thêm nếu chưa có nhãn "person"
                shape = {
                    "label": "person",
                    "points": det["points"],
                    "group_id": None,
                    "shape_type": "polygon",
                    "flags": {}
                }
                json_data["shapes"].append(shape)
            else:
                print(f"Nhãn 'person' đã tồn tại trong {json_path}, bỏ qua.")

    # Lưu file JSON
    with open(json_path, 'w') as f:
        json.dump(json_data, f, indent=4)
    print(f"Đã lưu file JSON: {json_path}")

# Xử lý từng ảnh trong thư mục
image_extensions = ('.jpg', '.jpeg', '.png')
for image_file in os.listdir(image_folder):
    if image_file.lower().endswith(image_extensions):
        image_path = os.path.join(image_folder, image_file)
        json_path = os.path.join(image_folder, os.path.splitext(image_file)[0] + '.json')

        # Đọc ảnh
        image = cv2.imread(image_path)
        if image is None:
            print(f"Không thể đọc ảnh: {image_path}")
            continue

        image_height, image_width = image.shape[:2]

        # Dự đoán với YOLO
        results = model.predict(image_path, conf=conf_threshold, iou=iou_threshold, imgsz=imgsz, classes=classes)

        # Xử lý kết quả dự đoán
        detections = []
        for result in results:
            if result.masks is not None:
                for mask, cls in zip(result.masks.data, result.boxes.cls):
                    if int(cls) == 0:  # Chỉ lấy class "person"
                        # Chuyển mask sang định dạng nhị phân
                        mask = mask.cpu().numpy().astype(np.uint8) * 255
                        mask = cv2.resize(mask, (image_width, image_height), interpolation=cv2.INTER_NEAREST)
                        points = mask_to_labelme_points(mask)
                        if points:
                            detections.append({"class": "person", "points": points[0]})  # Lấy contour đầu tiên

        # Tạo hoặc cập nhật file JSON
        if detections:
            create_or_update_json(image_path, json_path, detections, image_height, image_width)
        else:
            print(f"Không phát hiện 'person' trong ảnh: {image_path}")

print("Hoàn thành xử lý!")