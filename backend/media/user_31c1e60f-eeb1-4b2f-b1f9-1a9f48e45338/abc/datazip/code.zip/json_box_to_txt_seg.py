import os
import json
import shutil
from pathlib import Path
from tqdm import tqdm
import random

class SegToYOLOv8Converter:
    def __init__(self, input_dir, output_dir, split_data=False, train_ratio=0.8):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.split_data = split_data
        self.train_ratio = max(0.1, min(0.9, train_ratio))
        self.class_map = { 
            "person": 0,
            "gun1": 1,
            "gun2": 2,
            "stick": 3
        }
        self.image_extensions = [".jpg", ".jpeg", ".png", ".bmp"]
        
        self.stats = {
            "processed_files": 0,
            "skipped_files": 0,
            "annotations_by_type": {
                "box": 0,
                "polygon": 0,
                "rectangle": 0,
                "obb": 0,
                "other": 0
            },
            "annotations_by_class": {class_name: 0 for class_name in list(self.class_map.keys()) + ["unknown"]}
        }
        
    def setup_directories(self):
        if self.split_data:
            (self.output_dir / "train").mkdir(parents=True, exist_ok=True)
            (self.output_dir / "val").mkdir(parents=True, exist_ok=True)
        else:
            self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def get_file_pairs(self):
        file_pairs = []
        for file in self.input_dir.iterdir():
            if not file.is_file():
                continue
                
            if file.suffix.lower() not in self.image_extensions:
                continue
                
            json_path = file.with_suffix('.json')
            if json_path.exists():
                file_pairs.append((file, json_path))
        
        return file_pairs
    
    def convert_box_to_segmentation(self, points):
        if len(points) != 2:
            return points
        
        x1, y1 = points[0]
        x2, y2 = points[1]
        
        return [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]
    
    def convert_json_to_yolov8_seg(self, json_path, img_path, output_txt_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            img_width = data.get("imageWidth", 0)
            img_height = data.get("imageHeight", 0)
            
            if img_width <= 0 or img_height <= 0:
                print(f"Kích thước ảnh không hợp lệ trong {json_path}: {img_width}x{img_height}")
                self.stats["skipped_files"] += 1
                return False
            
            yolo_lines = []
            
            for shape in data.get("shapes", []):
                label = shape.get("label", "").lower()
                shape_type = shape.get("shape_type", "").lower()
                points = shape.get("points", [])
                
                if shape_type == "rectangle":
                    self.stats["annotations_by_type"]["rectangle"] += 1
                elif shape_type == "polygon":
                    self.stats["annotations_by_type"]["polygon"] += 1
                elif shape_type == "obb":
                    self.stats["annotations_by_type"]["obb"] += 1
                elif shape_type == "box":
                    self.stats["annotations_by_type"]["box"] += 1
                else:
                    self.stats["annotations_by_type"]["other"] += 1
                
                if label not in self.class_map:
                    print(f"Lớp không xác định {label} trong {json_path}")
                    self.stats["annotations_by_class"]["unknown"] += 1
                    continue
                
                self.stats["annotations_by_class"][label] += 1
                
                if shape_type == "rectangle" or len(points) == 2:
                    points = self.convert_box_to_segmentation(points)
                
                if len(points) < 3:
                    print(f"Đa giác không hợp lệ với {len(points)} điểm trong {json_path}")
                    continue
                    
                class_id = self.class_map[label]
                
                normalized_points = []
                for x, y in points:
                    x_norm = max(0, min(float(x), img_width - 1)) / img_width
                    y_norm = max(0, min(float(y), img_height - 1)) / img_height
                    normalized_points.extend([x_norm, y_norm])
                
                line = f"{class_id} " + " ".join(f"{x:.6f}" for x in normalized_points)
                yolo_lines.append(line)
            
            if yolo_lines:
                with open(output_txt_path, 'w', encoding='utf-8') as f:
                    f.write("\n".join(yolo_lines))
                self.stats["processed_files"] += 1
                return True
            else:
                print(f"Không tìm thấy chú thích hợp lệ trong {json_path}")
                self.stats["skipped_files"] += 1
                return False
                
        except Exception as e:
            print(f"Lỗi khi xử lý {json_path}: {str(e)}")
            self.stats["skipped_files"] += 1
            return False
    
    def process_dataset(self):
        self.setup_directories()
        file_pairs = self.get_file_pairs()
        
        if self.split_data:
            random.shuffle(file_pairs)
            train_count = int(len(file_pairs) * self.train_ratio)
            train_pairs = file_pairs[:train_count]
            val_pairs = file_pairs[train_count:]
            
            for img_path, json_path in tqdm(train_pairs, desc="Xử lý tập train"):
                img_filename = img_path.name
                txt_filename = img_path.stem + '.txt'
                
                output_txt = self.output_dir / "train" / txt_filename
                output_img = self.output_dir / "train" / img_filename
                
                if self.convert_json_to_yolov8_seg(json_path, img_path, output_txt):
                    shutil.copy(img_path, output_img)
            
            for img_path, json_path in tqdm(val_pairs, desc="Xử lý tập val"):
                img_filename = img_path.name
                txt_filename = img_path.stem + '.txt'
                
                output_txt = self.output_dir / "val" / txt_filename
                output_img = self.output_dir / "val" / img_filename
                
                if self.convert_json_to_yolov8_seg(json_path, img_path, output_txt):
                    shutil.copy(img_path, output_img)
        else:
            for img_path, json_path in tqdm(file_pairs, desc="Xử lý"):
                img_filename = img_path.name
                txt_filename = img_path.stem + '.txt'
                
                output_txt = self.output_dir / txt_filename
                output_img = self.output_dir / img_filename
                
                if self.convert_json_to_yolov8_seg(json_path, img_path, output_txt):
                    shutil.copy(img_path, output_img)
        
        print("\n===== THỐNG KÊ XỬ LÝ =====")
        print(f"Tổng số file xử lý: {len(file_pairs)}")
        print(f"Số file chuyển đổi thành công: {self.stats['processed_files']}")
        print(f"Số file bỏ qua: {self.stats['skipped_files']}")
        
        print("\nPhân loại theo loại chú thích:")
        for annotation_type, count in self.stats["annotations_by_type"].items():
            print(f"- {annotation_type}: {count} chú thích")
        
        print("\nPhân loại theo lớp:")
        for class_name, count in self.stats["annotations_by_class"].items():
            if count > 0:
                print(f"- {class_name}: {count} chú thích")
        
        print(f"\nKết quả được lưu vào {self.output_dir}")

def main():
    input_dir = "30_4/HungKHi_Training/aug_xoay_gun"
    output_dir = "30_4/HungKHi_Training/bo_sung_aug"
    converter = SegToYOLOv8Converter(input_dir, output_dir, split_data=True, train_ratio=0.8)
    converter.process_dataset()

if __name__ == "__main__":
    main()