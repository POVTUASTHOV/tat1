import os
import json
import cv2
import numpy as np
import shutil
from pathlib import Path

def process_large_images(input_dir, output_dir, problem_dir=None, target_width=1280, target_height=720):
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    if problem_dir:
        Path(problem_dir).mkdir(parents=True, exist_ok=True)
    
    image_files = [f for f in os.listdir(input_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    for image_file in image_files:
        try:
            image_path = os.path.join(input_dir, image_file)
            image = cv2.imread(image_path)
            
            if image is None:
                print(f"Không thể đọc hình ảnh: {image_path}")
                continue
            
            height, width = image.shape[:2]
            
            if width <= target_width and height <= target_height:
                print(f"Hình ảnh {image_file} đã nhỏ hơn kích thước mục tiêu, sao chép nguyên bản.")
                shutil.copy(image_path, os.path.join(output_dir, image_file))
                
                json_file = os.path.splitext(image_file)[0] + '.json'
                json_path = os.path.join(input_dir, json_file)
                if os.path.exists(json_path):
                    # Đọc và xóa imageData trước khi sao chép
                    try:
                        with open(json_path, 'r', encoding='utf-8') as f:
                            json_data = json.load(f)
                        
                        # Đặt imageData thành null
                        if 'imageData' in json_data:
                            json_data['imageData'] = None
                        
                        # Ghi lại file JSON đã chỉnh sửa
                        with open(os.path.join(output_dir, json_file), 'w', encoding='utf-8') as f:
                            json.dump(json_data, f, indent=4, ensure_ascii=False)
                    except Exception as e:
                        print(f"Lỗi khi xử lý JSON {json_file}: {e}")
                        shutil.copy(json_path, os.path.join(output_dir, json_file))
                continue
            
            json_file = os.path.splitext(image_file)[0] + '.json'
            json_path = os.path.join(input_dir, json_file)
            json_data = None
            bboxes = []
            priority_bboxes = []
            
            if os.path.exists(json_path):
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        json_data = json.load(f)
                    
                    # Đặt imageData thành null
                    if 'imageData' in json_data:
                        json_data['imageData'] = None
                    
                    if 'shapes' in json_data:
                        for shape in json_data['shapes']:
                            shape_type = shape.get('shape_type', '')
                            label = shape.get('label', '').lower()
                            
                            if shape_type == 'polygon' and 'points' in shape and len(shape['points']) >= 3:
                                points = np.array(shape['points'])
                                x_min, y_min = np.min(points, axis=0)
                                x_max, y_max = np.max(points, axis=0)
                                bbox = {'x1': x_min, 'y1': y_min, 'x2': x_max, 'y2': y_max, 'id': shape.get('id', ''), 'label': label}
                                bboxes.append(bbox)
                                if label in ['gun', 'knife', 'stick']:
                                    priority_bboxes.append(bbox)
                            elif (shape_type == 'rectangle' or not shape_type) and 'points' in shape and len(shape['points']) >= 2:
                                points = shape['points']
                                x1, y1 = points[0]
                                x2, y2 = points[1]
                                x1, x2 = min(x1, x2), max(x1, x2)
                                y1, y2 = min(y1, y2), max(y1, y2)
                                bbox = {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'id': shape.get('id', ''), 'label': label}
                                bboxes.append(bbox)
                                if label in ['gun', 'knife', 'stick']:
                                    priority_bboxes.append(bbox)
                    
                    elif 'objects' in json_data:
                        for obj in json_data['objects']:
                            if 'bbox' in obj:
                                bbox = obj['bbox']
                                label = obj.get('label', '').lower()
                                if len(bbox) == 4:
                                    if obj.get('format') == 'xyxy':
                                        x1, y1, x2, y2 = bbox
                                    else:
                                        x, y, w, h = bbox
                                        x1, y1, x2, y2 = x, y, x + w, y + h
                                    bbox = {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'id': obj.get('id', ''), 'label': label}
                                    bboxes.append(bbox)
                                    if label in ['gun', 'knife', 'stick']:
                                        priority_bboxes.append(bbox)
                
                except Exception as e:
                    print(f"Lỗi khi đọc JSON {json_file}: {e}")
                    if problem_dir:
                        shutil.copy(image_path, os.path.join(problem_dir, image_file))
                        if os.path.exists(json_path):
                            shutil.copy(json_path, os.path.join(problem_dir, json_file))
                    continue
                
                temp_priority_bboxes = priority_bboxes.copy()
                for bbox in bboxes:
                    if bbox['label'] == 'person':
                        for priority_bbox in temp_priority_bboxes:
                            if (bbox['x1'] < priority_bbox['x2'] and bbox['x2'] > priority_bbox['x1'] and
                                bbox['y1'] < priority_bbox['y2'] and bbox['y2'] > priority_bbox['y1']):
                                priority_bboxes.append(bbox)
                                break

            # Debug thông tin về bounding boxes
            print(f"Ảnh {image_file}: Tổng số bbox: {len(bboxes)}, Số bbox ưu tiên: {len(priority_bboxes)}")
            
            start_x, start_y = 0, 0
            end_x, end_y = target_width, target_height
            
            if priority_bboxes:
                left = min(box['x1'] for box in priority_bboxes)
                right = max(box['x2'] for box in priority_bboxes)
                top = min(box['y1'] for box in priority_bboxes)
                bottom = max(box['y2'] for box in priority_bboxes)
                
                center_x = (left + right) / 2
                center_y = (top + bottom) / 2
                
                print(f"Trung tâm ưu tiên: ({center_x}, {center_y})")
                
                start_x = max(0, int(center_x - target_width / 2))
                start_y = max(0, int(center_y - target_height / 2))
                
                if start_x + target_width > width:
                    start_x = max(0, width - target_width)
                if start_y + target_height > height:
                    start_y = max(0, height - target_height)
                
                end_x = min(width, start_x + target_width)
                end_y = min(height, start_y + target_height)
                
                # In thông tin về trạng thái của các đối tượng ưu tiên
                print(f"Tọa độ cắt: ({start_x}, {start_y}) -> ({end_x}, {end_y})")
                
                objects_visible = True
                for box in priority_bboxes:
                    box_width = box['x2'] - box['x1']
                    box_height = box['y2'] - box['y1']
                    
                    visible_left = max(box['x1'], start_x)
                    visible_right = min(box['x2'], end_x)
                    visible_top = max(box['y1'], start_y)
                    visible_bottom = min(box['y2'], end_y)
                    
                    visible_width = max(0, visible_right - visible_left)
                    visible_height = max(0, visible_bottom - visible_top)
                    
                    width_visibility = visible_width / box_width if box_width > 0 else 0
                    height_visibility = visible_height / box_height if box_height > 0 else 0
                    
                    print(f"Đối tượng {box['label']}: Tọa độ ({box['x1']}, {box['y1']}) -> ({box['x2']}, {box['y2']})")
                    print(f"  Độ nhìn thấy: Chiều rộng {width_visibility:.2f}, Chiều cao {height_visibility:.2f}")
                    
                    if width_visibility < 0.7 or height_visibility < 0.7:
                        objects_visible = False
                        print(f"  ⚠️ Đối tượng này không đủ nhìn thấy (< 70%)")
                
                if not objects_visible and problem_dir:
                    shutil.copy(image_path, os.path.join(problem_dir, image_file))
                    if os.path.exists(json_path):
                        shutil.copy(json_path, os.path.join(problem_dir, json_file))
                    print(f"Đối tượng ưu tiên trong {image_file} bị cắt quá nhiều, chuyển sang thư mục vấn đề")
                    continue
            elif bboxes:
                left = min(box['x1'] for box in bboxes)
                right = max(box['x2'] for box in bboxes)
                top = min(box['y1'] for box in bboxes)
                bottom = max(box['y2'] for box in bboxes)
                
                center_x = (left + right) / 2
                center_y = (top + bottom) / 2
                
                print(f"Trung tâm tất cả đối tượng: ({center_x}, {center_y})")
                
                start_x = max(0, int(center_x - target_width / 2))
                start_y = max(0, int(center_y - target_height / 2))
                
                if start_x + target_width > width:
                    start_x = max(0, width - target_width)
                if start_y + target_height > height:
                    start_y = max(0, height - target_height)
                
                end_x = min(width, start_x + target_width)
                end_y = min(height, start_y + target_height)
                
                print(f"Tọa độ cắt: ({start_x}, {start_y}) -> ({end_x}, {end_y})")

                objects_visible = True
                for box in bboxes:
                    box_width = box['x2'] - box['x1']
                    box_height = box['y2'] - box['y1']
                    
                    visible_left = max(box['x1'], start_x)
                    visible_right = min(box['x2'], end_x)
                    visible_top = max(box['y1'], start_y)
                    visible_bottom = min(box['y2'], end_y)
                    
                    visible_width = max(0, visible_right - visible_left)
                    visible_height = max(0, visible_bottom - visible_top)
                    
                    width_visibility = visible_width / box_width if box_width > 0 else 0
                    height_visibility = visible_height / box_height if box_height > 0 else 0
                    
                    print(f"Đối tượng {box['label']}: Tọa độ ({box['x1']}, {box['y1']}) -> ({box['x2']}, {box['y2']})")
                    print(f"  Độ nhìn thấy: Chiều rộng {width_visibility:.2f}, Chiều cao {height_visibility:.2f}")
                    
                    if width_visibility < 0.7 or height_visibility < 0.7:
                        objects_visible = False
                        print(f"  ⚠️ Đối tượng này không đủ nhìn thấy (< 70%)")
                
                if not objects_visible and problem_dir:
                    shutil.copy(image_path, os.path.join(problem_dir, image_file))
                    if os.path.exists(json_path):
                        shutil.copy(json_path, os.path.join(problem_dir, json_file))
                    print(f"Đối tượng trong {image_file} bị cắt quá nhiều, chuyển sang thư mục vấn đề")
                    continue
            else:
                start_x = max(0, (width - target_width) // 2)
                start_y = max(0, (height - target_height) // 2)
                end_x = min(width, start_x + target_width)
                end_y = min(height, start_y + target_height)
                print(f"Không có đối tượng, cắt ở trung tâm: ({start_x}, {start_y}) -> ({end_x}, {end_y})")
            
            start_x = max(0, min(start_x, width - target_width))
            start_y = max(0, min(start_y, height - target_height))
            end_x = min(width, start_x + target_width)
            end_y = min(height, start_y + target_height)
            
            actual_width = end_x - start_x
            actual_height = end_y - start_y
            
            print(f"Cắt hình ảnh {image_file} từ ({start_x}, {start_y}) đến ({end_x}, {end_y}), kích thước: {actual_width}x{actual_height}")
            
            cropped_image = image[start_y:end_y, start_x:end_x]
            
            output_image_path = os.path.join(output_dir, image_file)
            cv2.imwrite(output_image_path, cropped_image)
            
            # Khi hình ảnh được cắt nhỏ hơn kích thước mục tiêu, điều chỉnh để tránh lỗi tọa độ
            if actual_width < target_width or actual_height < target_height:
                resized_image = np.zeros((target_height, target_width, 3), dtype=np.uint8)
                resized_image[0:actual_height, 0:actual_width] = cropped_image
                cv2.imwrite(output_image_path, resized_image)
            
            if json_data and os.path.exists(json_path):
                if 'shapes' in json_data:
                    new_shapes = []
                    for shape in json_data['shapes']:
                        shape_type = shape.get('shape_type', '')
                        label = shape.get('label', '')
                        
                        if shape_type == 'polygon' and 'points' in shape and len(shape['points']) >= 3:
                            points = np.array(shape['points'])
                            x_min, y_min = np.min(points, axis=0)
                            x_max, y_max = np.max(points, axis=0)
                            original_area = (x_max - x_min) * (y_max - y_min)
                            
                            visible_left = max(x_min, start_x)
                            visible_right = min(x_max, end_x)
                            visible_top = max(y_min, start_y)
                            visible_bottom = min(y_max, end_y)
                            visible_area = max(0, visible_right - visible_left) * max(0, visible_bottom - visible_top)
                            
                            visibility_ratio = visible_area / original_area if original_area > 0 else 0
                            print(f"  Đối tượng {label} (polygon): Tỷ lệ nhìn thấy {visibility_ratio:.2f}")
                            
                            # Sử dụng ngưỡng khác nhau cho đối tượng ưu tiên và đối tượng thường
                            threshold = 0.6
                            if label.lower() in ['gun', 'knife', 'stick']:
                                threshold = 0.5  # Giảm ngưỡng cho đối tượng ưu tiên
                            
                            if visibility_ratio >= threshold:
                                new_points = []
                                for point in shape['points']:
                                    x, y = point
                                    # Trừ tọa độ cắt
                                    new_x = x - start_x
                                    new_y = y - start_y
                                    # Đảm bảo nằm trong phạm vi hình ảnh mới
                                    new_x = max(0, min(actual_width, new_x))
                                    new_y = max(0, min(actual_height, new_y))
                                    new_points.append([new_x, new_y])
                                shape['points'] = new_points
                                new_shapes.append(shape)
                                print(f"  ✓ Giữ lại đối tượng {label}")
                            else:
                                print(f"  ✗ Loại bỏ đối tượng {label} (tỷ lệ nhìn thấy < {threshold})")
                            
                        elif (shape_type == 'rectangle' or not shape_type) and 'points' in shape and len(shape['points']) >= 2:
                            points = shape['points']
                            x1, y1 = points[0]
                            x2, y2 = points[1]
                            x1, x2 = min(x1, x2), max(x1, x2)
                            y1, y2 = min(y1, y2), max(y1, y2)
                            original_area = (x2 - x1) * (y2 - y1)
                            
                            visible_left = max(x1, start_x)
                            visible_right = min(x2, end_x)
                            visible_top = max(y1, start_y)
                            visible_bottom = min(y2, end_y)
                            visible_area = max(0, visible_right - visible_left) * max(0, visible_bottom - visible_top)
                            
                            visibility_ratio = visible_area / original_area if original_area > 0 else 0
                            print(f"  Đối tượng {label} (rectangle): Tỷ lệ nhìn thấy {visibility_ratio:.2f}")
                            
                            # Sử dụng ngưỡng khác nhau cho đối tượng ưu tiên và đối tượng thường
                            threshold = 0.7
                            if label.lower() in ['gun', 'knife', 'stick']:
                                threshold = 0.5  # Giảm ngưỡng cho đối tượng ưu tiên
                            
                            if visibility_ratio >= threshold:
                                # Trừ tọa độ cắt
                                new_x1 = x1 - start_x
                                new_y1 = y1 - start_y
                                new_x2 = x2 - start_x
                                new_y2 = y2 - start_y
                                
                                # Đảm bảo nằm trong phạm vi hình ảnh mới
                                new_x1 = max(0, min(actual_width, new_x1))
                                new_y1 = max(0, min(actual_height, new_y1))
                                new_x2 = max(0, min(actual_width, new_x2))
                                new_y2 = max(0, min(actual_height, new_y2))
                                
                                shape['points'] = [[new_x1, new_y1], [new_x2, new_y2]]
                                new_shapes.append(shape)
                                print(f"  ✓ Giữ lại đối tượng {label}")
                            else:
                                print(f"  ✗ Loại bỏ đối tượng {label} (tỷ lệ nhìn thấy < {threshold})")
                    
                    json_data['shapes'] = new_shapes
                    json_data['imageWidth'] = actual_width
                    json_data['imageHeight'] = actual_height
                    if json_data.get('imagePath'):
                        json_data['imagePath'] = image_file
                
                elif 'objects' in json_data:
                    new_objects = []
                    for obj in json_data['objects']:
                        if 'bbox' in obj:
                            bbox = obj['bbox']
                            label = obj.get('label', '')
                            if len(bbox) == 4:
                                if obj.get('format') == 'xyxy':
                                    x1, y1, x2, y2 = bbox
                                else:
                                    x, y, w, h = bbox
                                    x1, y1, x2, y2 = x, y, x + w, y + h
                                original_area = (x2 - x1) * (y2 - y1)
                                
                                visible_left = max(x1, start_x)
                                visible_right = min(x2, end_x)
                                visible_top = max(y1, start_y)
                                visible_bottom = min(y2, end_y)
                                visible_area = max(0, visible_right - visible_left) * max(0, visible_bottom - visible_top)
                                
                                visibility_ratio = visible_area / original_area if original_area > 0 else 0
                                print(f"  Đối tượng {label} (bbox): Tỷ lệ nhìn thấy {visibility_ratio:.2f}")
                                
                                # Sử dụng ngưỡng khác nhau cho đối tượng ưu tiên và đối tượng thường
                                threshold = 0.6
                                if label.lower() in ['gun', 'knife', 'stick']:
                                    threshold = 0.5  # Giảm ngưỡng cho đối tượng ưu tiên
                                
                                if visibility_ratio >= threshold:
                                    # Điều chỉnh tọa độ dựa vào vị trí cắt
                                    new_x1 = x1 - start_x
                                    new_y1 = y1 - start_y
                                    new_x2 = x2 - start_x
                                    new_y2 = y2 - start_y
                                    
                                    # Đảm bảo tọa độ nằm trong phạm vi hình ảnh mới
                                    new_x1 = max(0, min(actual_width, new_x1))
                                    new_y1 = max(0, min(actual_height, new_y1))
                                    new_x2 = max(0, min(actual_width, new_x2))
                                    new_y2 = max(0, min(actual_height, new_y2))
                                    
                                    if obj.get('format') == 'xyxy':
                                        obj['bbox'] = [new_x1, new_y1, new_x2, new_y2]
                                    else:
                                        new_w = new_x2 - new_x1
                                        new_h = new_y2 - new_y1
                                        obj['bbox'] = [new_x1, new_y1, new_w, new_h]
                                    new_objects.append(obj)
                                    print(f"  ✓ Giữ lại đối tượng {label}")
                                else:
                                    print(f"  ✗ Loại bỏ đối tượng {label} (tỷ lệ nhìn thấy < {threshold})")
                        
                        if 'segmentation' in obj:
                            if isinstance(obj['segmentation'], list):
                                new_segmentation = []
                                for polygon in obj['segmentation']:
                                    new_polygon = []
                                    for i in range(0, len(polygon), 2):
                                        if i + 1 < len(polygon):
                                            x, y = polygon[i], polygon[i+1]
                                            # Trừ tọa độ cắt
                                            new_x = x - start_x
                                            new_y = y - start_y
                                            # Đảm bảo nằm trong phạm vi hình ảnh mới
                                            new_x = max(0, min(actual_width, new_x))
                                            new_y = max(0, min(actual_height, new_y))
                                            new_polygon.extend([new_x, new_y])
                                    new_segmentation.append(new_polygon)
                                obj['segmentation'] = new_segmentation
                
                    json_data['objects'] = new_objects
                
                # Đảm bảo imageData được đặt thành null
                json_data['imageData'] = None
                
                if json_data.get('width'):
                    json_data['width'] = actual_width
                if json_data.get('height'):
                    json_data['height'] = actual_height
                if json_data.get('path'):
                    json_data['path'] = image_file
                
                output_json_path = os.path.join(output_dir, json_file)
                with open(output_json_path, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=4, ensure_ascii=False)
            
        except Exception as e:
            print(f"Lỗi khi xử lý {image_file}: {e}")
            if problem_dir:
                try:
                    shutil.copy(image_path, os.path.join(problem_dir, image_file))
                    json_path = os.path.join(input_dir, os.path.splitext(image_file)[0] + '.json')
                    if os.path.exists(json_path):
                        shutil.copy(json_path, os.path.join(problem_dir, os.path.splitext(image_file)[0] + '.json'))
                except Exception as copy_error:
                    print(f"Lỗi khi sao chép sang thư mục vấn đề: {copy_error}")
    
    print(f"Hoàn tất xử lý. Hình ảnh và chú thích được lưu vào {output_dir}")

if __name__ == "__main__":
    input_directory = r"D:\bai_toan\weapon\13_4\tong\hop"
    output_directory = r"D:\bai_toan\weapon\13_4\tong\hop\output"
    problem_directory = r"D:\bai_toan\weapon\13_4\tong\hop\problem"

    process_large_images(input_directory, output_directory, problem_directory, target_width=1280, target_height=720)