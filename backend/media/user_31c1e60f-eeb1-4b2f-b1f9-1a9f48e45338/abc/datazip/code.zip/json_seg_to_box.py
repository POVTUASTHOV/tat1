import os
import json
import numpy as np
import shutil
from pathlib import Path

def get_bounding_box(points):
    points_array = np.array(points)
    x_min = float(np.min(points_array[:, 0]))
    y_min = float(np.min(points_array[:, 1]))
    x_max = float(np.max(points_array[:, 0]))
    y_max = float(np.max(points_array[:, 1]))
    return [x_min, y_min, x_max, y_max]

def convert_segmentation_to_box(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    boxes_data = {
        "version": data.get("version", ""),
        "flags": data.get("flags", {}),
        "shapes": [],
        "imagePath": data.get("imagePath", ""),
        "imageData": None,
        "imageHeight": data.get("imageHeight", 0),
        "imageWidth": data.get("imageWidth", 0)
    }
    
    for shape in data.get("shapes", []):
        if shape["shape_type"] in ["polygon", "linestrip"]:
            box = get_bounding_box(shape["points"])
            box_shape = {
                "label": shape["label"],
                "points": [[box[0], box[1]], [box[2], box[3]]],
                "group_id": shape.get("group_id", None),
                "shape_type": "rectangle",
                "flags": shape.get("flags", {})
            }
            boxes_data["shapes"].append(box_shape)
        elif shape["shape_type"] == "rectangle":
            boxes_data["shapes"].append(shape)
    
    return boxes_data

def process_directory(input_dir, output_dir):
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    
    if not output_path.exists():
        output_path.mkdir(parents=True)
    
    json_files = list(input_path.glob("*.json"))
    print(f"Found {len(json_files)} JSON files to process")
    
    for i, json_file in enumerate(json_files):
        try:
            box_data = convert_segmentation_to_box(json_file)
            
            output_json_path = output_path / json_file.name
            with open(output_json_path, 'w', encoding='utf-8') as f:
                json.dump(box_data, f, ensure_ascii=False, indent=2)
            
            image_filename = box_data["imagePath"]
            image_path = input_path / image_filename
            
            if image_path.exists():
                shutil.copy(image_path, output_path / image_filename)
            
            if (i + 1) % 10 == 0:
                print(f"Processed {i + 1}/{len(json_files)} files")
                
        except Exception as e:
            print(f"Error processing {json_file}: {e}")

if __name__ == "__main__":
    input_directory = r"D:\bai_toan\Traffic\them_du_lieu\q\tong"
    output_directory = r"D:\bai_toan\Traffic\them_du_lieu\q\box"
    
    print(f"Converting segmentation annotations to bounding boxes")
    print(f"Input directory: {input_directory}")
    print(f"Output directory: {output_directory}")
    
    process_directory(input_directory, output_directory)
    print(f"Conversion completed. Results saved to {output_directory}")