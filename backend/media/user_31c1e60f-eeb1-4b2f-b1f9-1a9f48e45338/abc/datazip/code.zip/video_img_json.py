import cv2
import os
import json
import ntpath
from ultralytics import YOLO
import numpy as np
from datetime import datetime

class VideoProcessor:
    def __init__(self, video_path, model_path):
        self.video_path = video_path
        self.video_name = ntpath.basename(video_path).split('.')[0]
        self.model = YOLO(model_path)
        self.output_dir = self.video_name
        os.makedirs(self.output_dir, exist_ok=True)
        
        self.cap = cv2.VideoCapture(video_path)
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.frame_count = 0
        self.saved_frames = 0
    
    def process(self, interval=5, conf, iou, classes):
        seq_number = 1
        
        while self.cap.isOpened():
            success, frame = self.cap.read()
            
            if not success:
                break
                
            self.frame_count += 1
            
            if self.frame_count % interval == 0:
                frame = frame[180:180+720, 320:320+1280]
                results = self.model(frame, imgsz=1280, iou=iou, conf=conf, classes=classes)
                annotated_frame = results[0].plot()
                
                base_filename = f"{self.video_name}_{seq_number}"
                frame_filename = f"{base_filename}.jpg"
                json_filename = f"{base_filename}.json"
                
                frame_path = os.path.join(self.output_dir, frame_filename)
                json_path = os.path.join(self.output_dir, json_filename)
                
                cv2.imwrite(frame_path, frame)
                
                boxes = results[0].boxes.xyxy.cpu().numpy()
                class_ids = results[0].boxes.cls.cpu().numpy()
                confidences = results[0].boxes.conf.cpu().numpy()
                
                labelme_json = {
                    "version": "4.5.6",
                    "flags": {},
                    "shapes": [],
                    "imagePath": frame_filename,
                    "imageData": None,
                    "imageHeight": self.height,
                    "imageWidth": self.width
                }
                
                for i in range(len(boxes)):
                    box = boxes[i]
                    class_id = int(class_ids[i])
                    confidence = float(confidences[i])
                    
                    class_name = "person"
                    if class_id == 0:
                        class_name = "person"
                    
                    points = [
                        [float(box[0]), float(box[1])],
                        [float(box[2]), float(box[3])]
                    ]
                    
                    shape = {
                        "label": class_name,
                        "points": points,
                        "group_id": None,
                        "shape_type": "rectangle",
                        "flags": {}
                    }
                    
                    labelme_json["shapes"].append(shape)
                
                with open(json_path, 'w') as f:
                    json.dump(labelme_json, f, indent=2)
                
                cv2.imshow("YOLO Inference", annotated_frame)
                
                seq_number += 1
                self.saved_frames += 1
                
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
        
        self.cap.release()
        cv2.destroyAllWindows()
        
        return {
            "total_frames": self.frame_count,
            "saved_frames": self.saved_frames,
            "output_dir": self.output_dir
        }

if __name__ == "__main__":
    video_path = "Traffic/4_9/DJI_0376_W.MP4"
    model_path = "/media/tat/Learn1/bai_toan/yolo11x-seg.pt"
    classes = [0, 2, 3]
    conf = 0.5
    iou = 0.5
    processor = VideoProcessor(video_path, model_path)

    results = processor.process(interval=5, conf=conf, iou=iou, classes=classes)
    
    print(f"Processing complete. Total frames: {results['total_frames']}")
    print(f"Saved {results['saved_frames']} frames and annotations to {results['output_dir']}")