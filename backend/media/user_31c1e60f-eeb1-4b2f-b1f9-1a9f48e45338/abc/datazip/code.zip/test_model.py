import cv2
import time
from ultralytics import YOLO

def resize_with_aspect_ratio(image, width=None, height=None):
    h, w = image.shape[:2]
    
    if width is None and height is None:
        return image
    
    if width is None:
        aspect_ratio = height / h
        dimension = (int(w * aspect_ratio), height)
    else:
        aspect_ratio = width / w
        dimension = (width, int(h * aspect_ratio))
    
    return cv2.resize(image, dimension, interpolation=cv2.INTER_AREA)

def run_inference():
    cap = cv2.VideoCapture("Traffic/video_v2/istockphoto-2187245911-640_adpp_is.mp4")
    model = YOLO("yolo11s-seg.pt")
    
    window_name = "YOLO Inference"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 1280, 720)
    
    prev_time = 0
    curr_time = 0
    fps = 0
    
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break
            
        curr_time = time.time()
        fps = 1 / (curr_time - prev_time) if (curr_time - prev_time) > 0 else 0
        prev_time = curr_time
        
        #frame = frame[180:180+720, 320:320+1280]
        #frame = frame[300:300+480, 640:640+640]
        #frame = cv2.resize(frame, (1280, 720), interpolation=cv2.INTER_AREA)
        results = model(frame, iou=0.6, conf=0.4, imgsz=768)
        annotated_frame = results[0].plot(line_width=2, font_size=0.2)
        
        cv2.putText(annotated_frame, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        display_frame = resize_with_aspect_ratio(annotated_frame, width=1280, height=720)
        
        cv2.imshow(window_name, display_frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_inference()