import os
import json
import glob
import numpy as np
from tqdm import tqdm
from PIL import Image

class YoloToLabelmeConverter:
    def __init__(self, dataset_dir, class_names):
        self.dataset_dir = os.path.abspath(dataset_dir)
        self.class_names = class_names
        self.txt_files = []
        self.img_files = []
    
    def find_files(self):
        print(f"Searching for files in: {self.dataset_dir}")
        
        if not os.path.exists(self.dataset_dir):
            print(f"Error: Directory {self.dataset_dir} does not exist")
            return
            
        txt_pattern = os.path.join(self.dataset_dir, "**/*.txt")
        print(f"Using pattern: {txt_pattern}")
        
        all_files = glob.glob(txt_pattern, recursive=True)
        print(f"Total files found: {len(all_files)}")
        
        self.txt_files = []
        self.img_files = []
        img_extensions = ['.jpg', '.jpeg', '.png']
        
        for txt_file in all_files:
            if os.path.basename(txt_file) == "classes.txt":
                continue
                
            found_img = False
            for ext in img_extensions:
                img_file = os.path.splitext(txt_file)[0] + ext
                if os.path.exists(img_file):
                    self.txt_files.append(txt_file)
                    self.img_files.append(img_file)
                    found_img = True
                    break
            
            if not found_img:
                print(f"No image found for: {txt_file}")
        
        print(f"Found {len(self.txt_files)} annotation files with corresponding images")
        
        if len(self.txt_files) == 0:
            print("Listing all .txt files found:")
            for txt in all_files:
                print(f"- {txt}")
    
    def is_segmentation(self, parts):
        return len(parts) > 5 and (len(parts) - 1) % 2 == 0
    
    def convert_yolo_to_labelme(self, txt_file, img_file):
        try:
            img = Image.open(img_file)
            img_width, img_height = img.size
            
            with open(txt_file, 'r') as f:
                lines = f.read().strip().split('\n')
            
            shapes = []
            for line in lines:
                if not line.strip():
                    continue
                    
                parts = line.strip().split()
                if len(parts) < 5:
                    print(f"Warning: Invalid format in {txt_file}: {line}")
                    continue
                
                class_id = int(parts[0])
                if class_id >= len(self.class_names):
                    print(f"Warning: Class ID {class_id} is out of range in {txt_file}")
                    continue
                
                if self.is_segmentation(parts):
                    points = []
                    for i in range(1, len(parts), 2):
                        x = float(parts[i]) * img_width
                        y = float(parts[i+1]) * img_height
                        points.append([x, y])
                    
                    shape = {
                        "label": self.class_names[class_id],
                        "points": points,
                        "group_id": None,
                        "shape_type": "polygon",
                        "flags": {}
                    }
                else:
                    x_center = float(parts[1])
                    y_center = float(parts[2])
                    width = float(parts[3])
                    height = float(parts[4])
                    
                    x_min = (x_center - width/2) * img_width
                    y_min = (y_center - height/2) * img_height
                    x_max = (x_center + width/2) * img_width
                    y_max = (y_center + height/2) * img_height
                    
                    shape = {
                        "label": self.class_names[class_id],
                        "points": [[x_min, y_min], [x_max, y_max]],
                        "group_id": None,
                        "shape_type": "rectangle",
                        "flags": {}
                    }
                
                shapes.append(shape)
            
            labelme_data = {
                "version": "4.5.7",
                "flags": {},
                "shapes": shapes,
                "imagePath": os.path.basename(img_file),
                "imageData": None,
                "imageHeight": img_height,
                "imageWidth": img_width
            }
            
            json_path = os.path.splitext(img_file)[0] + ".json"
            with open(json_path, 'w') as f:
                json.dump(labelme_data, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error converting {txt_file}: {str(e)}")
            return False
    
    def convert_all(self):
        if not self.txt_files:
            print("No files to convert.")
            return
            
        success_count = 0
        
        for txt_file, img_file in tqdm(zip(self.txt_files, self.img_files), total=len(self.txt_files), desc="Converting annotations"):
            if self.convert_yolo_to_labelme(txt_file, img_file):
                success_count += 1
        
        print(f"Successfully converted {success_count}/{len(self.txt_files)} annotations")

dataset_dir = "/media/tat/Learn1/bai_toan/Traffic/dro/person"
class_names = ['person']

converter = YoloToLabelmeConverter(dataset_dir, class_names)
converter.find_files()
converter.convert_all()