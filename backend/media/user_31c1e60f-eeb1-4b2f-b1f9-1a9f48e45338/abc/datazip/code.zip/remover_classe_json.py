import os
import json
import glob
import shutil
from pathlib import Path
from tqdm import tqdm

class LabelmeClassRemover:
    def __init__(self, input_dir, output_dir, classes_to_remove):
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.classes_to_remove = classes_to_remove
        self.label_counts = {}
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
    def process_files(self):
        json_files = glob.glob(os.path.join(self.input_dir, "*.json"))
        
        for json_file in tqdm(json_files, desc="Processing files"):
            try:
                base_filename = os.path.basename(json_file)
                image_filename = os.path.splitext(base_filename)[0]
                
                for ext in ['.jpg', '.jpeg', '.png']:
                    image_path = os.path.join(self.input_dir, f"{image_filename}{ext}")
                    if os.path.exists(image_path):
                        break
                else:
                    continue
                
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                if "shapes" in data:
                    original_shapes_count = len(data["shapes"])
                    data["shapes"] = [shape for shape in data["shapes"] if shape.get("label") not in self.classes_to_remove]
                    
                    if len(data["shapes"]) > 0:
                        for shape in data["shapes"]:
                            label = shape.get("label", "unknown")
                            self.label_counts[label] = self.label_counts.get(label, 0) + 1
                        
                        output_json_path = os.path.join(self.output_dir, base_filename)
                        with open(output_json_path, 'w', encoding='utf-8') as f:
                            json.dump(data, f, indent=2, ensure_ascii=False)
                        
                        shutil.copy(image_path, os.path.join(self.output_dir, os.path.basename(image_path)))
            except Exception as e:
                print(f"Error processing {json_file}: {str(e)}")
    
    def print_statistics(self):
        print("\nRemaining Label Statistics:")
        print("=" * 40)
        
        sorted_labels = sorted(self.label_counts.items(), key=lambda x: x[1], reverse=True)
        
        for label, count in sorted_labels:
            print(f"{label}: {count} instances")
        
        print("=" * 40)
        print(f"Total unique labels: {len(self.label_counts)}")
        print(f"Total annotations: {sum(self.label_counts.values())}")

def main():
    input_dir = r"D:\bai_toan\weapon\13_4\tong\0380"
    output_dir = r"D:\bai_toan\weapon\13_4\tong\0380_1"
    classes_to_remove = ['person']
    
    remover = LabelmeClassRemover(input_dir, output_dir, classes_to_remove)
    remover.process_files()
    remover.print_statistics()

if __name__ == "__main__":
    main()