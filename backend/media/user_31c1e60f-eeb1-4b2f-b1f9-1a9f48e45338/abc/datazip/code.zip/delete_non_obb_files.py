import os
import json
import numpy as np

def calculate_sides_and_angles(points):
    sides = []
    angles = []
    
    n = len(points)
    for i in range(n):
        p1 = np.array(points[i])
        p2 = np.array(points[(i+1) % n])
        side = np.linalg.norm(p2 - p1)
        sides.append(side)
    
    for i in range(n):
        p1 = np.array(points[(i-1) % n])
        p2 = np.array(points[i])
        p3 = np.array(points[(i+1) % n])
        
        v1 = p1 - p2
        v2 = p3 - p2
        
        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        if norm_v1 == 0 or norm_v2 == 0:
            return None, None
        
        cos_angle = dot_product / (norm_v1 * norm_v2)
        cos_angle = max(min(cos_angle, 1.0), -1.0)
        angle = np.arccos(cos_angle) * 180.0 / np.pi
        angles.append(angle)
    
    return sides, angles

def is_rectangle(points, tolerance=5.0):
    if len(points) != 4:
        return False
    
    sides, angles = calculate_sides_and_angles(points)
    if sides is None or angles is None:
        return False
    
    for angle in angles:
        if abs(angle - 90) > tolerance:
            return False
    
    return True

def delete_non_obb_files(input_dir):
    deleted_files = []
    image_extensions = [".jpg", ".jpeg", ".png", ".bmp"]
    
    for filename in os.listdir(input_dir):
        if filename.endswith('.json'):
            json_path = os.path.join(input_dir, filename)
            
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                is_non_obb = False
                for shape in data.get('shapes', []):
                    shape_type = shape.get('shape_type', '')
                    points = shape.get('points', [])
                    
                    if shape_type == 'polygon':
                        if len(points) == 4:
                            if not is_rectangle(points):
                                is_non_obb = True
                                break
                        else:
                            is_non_obb = True
                            break
                    elif shape_type == 'rectangle':
                        continue  # Chấp nhận rectangle
                    else:
                        is_non_obb = True
                        break
                
                if is_non_obb:
                    # Xóa file JSON
                    os.remove(json_path)
                    deleted_files.append(json_path)
                    print(f"Deleted JSON: {json_path}")
                    
                    # Xóa file ảnh tương ứng
                    base_name = os.path.splitext(filename)[0]
                    for ext in image_extensions:
                        img_path = os.path.join(input_dir, f"{base_name}{ext}")
                        if os.path.exists(img_path):
                            os.remove(img_path)
                            deleted_files.append(img_path)
                            print(f"Deleted image: {img_path}")
                            break
            
            except Exception as e:
                print(f"Error processing {json_path}: {str(e)}")
    
    print(f"\nDeleted {len(deleted_files)} files:")
    for file in deleted_files:
        print(f"- {file}")
    
    if len(deleted_files) == 0:
        print("No non-OBB files found to delete.")

if __name__ == "__main__":
    input_dir = "/media/tat/Learn1/bai_toan/weapon/3_26/tong/obb/dataset/0356_output"
    delete_non_obb_files(input_dir)