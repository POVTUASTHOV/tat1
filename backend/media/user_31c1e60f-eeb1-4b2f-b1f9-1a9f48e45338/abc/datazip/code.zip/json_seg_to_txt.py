import os
import json
import shutil
from pathlib import Path
from tqdm import tqdm
import random

class SegToYOLOv8Converter:
    def __init__(self, input_dir, output_dir, split_data=False, train_ratio=0.8):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.split_data = split_data
        self.train_ratio = max(0.1, min(0.9, train_ratio))  # Giới hạn tỷ lệ train từ 10% đến 90%
        self.class_map = { 
            "person": 0,
            "gun1": 1,
            "gun2": 2,
            "stick": 3
        }
        # self.class_map = {
        #     "car": 0,
        #     "motor": 1,
        #     "accident": 2,
        #     "person": 3
        # }
        self.image_extensions = [".jpg", ".jpeg", ".png", ".bmp"]
        
    def setup_directories(self):
        if self.split_data:
            (self.output_dir / "train").mkdir(parents=True, exist_ok=True)
            (self.output_dir / "val").mkdir(parents=True, exist_ok=True)
        else:
            self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def get_file_pairs(self):
        file_pairs = []
        for file in self.input_dir.iterdir():
            if not file.is_file():
                continue
                
            if file.suffix.lower() not in self.image_extensions:
                continue
                
            json_path = file.with_suffix('.json')
            if json_path.exists():
                file_pairs.append((file, json_path))
        
        return file_pairs
    
    def convert_json_to_yolov8_seg(self, json_path, img_path, output_txt_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            img_width = data.get("imageWidth", 0)
            img_height = data.get("imageHeight", 0)
            
            if img_width <= 0 or img_height <= 0:
                print(f"Kích thước ảnh không hợp lệ trong {json_path}: {img_width}x{img_height}")
                return False
            
            yolo_lines = []
            
            for shape in data.get("shapes", []):
                label = shape.get("label", "").lower()
                shape_type = shape.get("shape_type", "")
                points = shape.get("points", [])
                
                if shape_type != "polygon":
                    print(f"Bỏ qua shape_type {shape_type} trong {json_path}")
                    continue
                
                if label not in self.class_map:
                    print(f"Lớp không xác định {label} trong {json_path}")
                    continue
                
                class_id = self.class_map[label]
                
                if len(points) < 3:
                    print(f"Đa giác không hợp lệ với {len(points)} điểm trong {json_path}")
                    continue
                
                normalized_points = []
                for x, y in points:
                    x_norm = max(0, min(float(x), img_width - 1)) / img_width
                    y_norm = max(0, min(float(y), img_height - 1)) / img_height
                    normalized_points.extend([x_norm, y_norm])
                
                line = f"{class_id} " + " ".join(f"{x:.6f}" for x in normalized_points)
                yolo_lines.append(line)
            
            if yolo_lines:
                with open(output_txt_path, 'w', encoding='utf-8') as f:
                    f.write("\n".join(yolo_lines))
                return True
            else:
                print(f"Không tìm thấy chú thích hợp lệ trong {json_path}")
                return False
                
        except Exception as e:
            print(f"Lỗi khi xử lý {json_path}: {e}")
            return False
    
    def process_dataset(self):
        self.setup_directories()
        file_pairs = self.get_file_pairs()
        
        if self.split_data:
            # Xáo trộn ngẫu nhiên các cặp file
            random.shuffle(file_pairs)
            train_count = int(len(file_pairs) * self.train_ratio)
            train_pairs = file_pairs[:train_count]
            val_pairs = file_pairs[train_count:]
            
            # Xử lý tập train
            for img_path, json_path in tqdm(train_pairs, desc="Xử lý tập train"):
                img_filename = img_path.name
                txt_filename = img_path.stem + '.txt'
                
                output_txt = self.output_dir / "train" / txt_filename
                output_img = self.output_dir / "train" / img_filename
                
                if self.convert_json_to_yolov8_seg(json_path, img_path, output_txt):
                    shutil.copy(img_path, output_img)
            
            # Xử lý tập val
            for img_path, json_path in tqdm(val_pairs, desc="Xử lý tập val"):
                img_filename = img_path.name
                txt_filename = img_path.stem + '.txt'
                
                output_txt = self.output_dir / "val" / txt_filename
                output_img = self.output_dir / "val" / img_filename
                
                if self.convert_json_to_yolov8_seg(json_path, img_path, output_txt):
                    shutil.copy(img_path, output_img)
        else:
            # Không chia dữ liệu, lưu tất cả vào output_dir
            for img_path, json_path in tqdm(file_pairs, desc="Xử lý"):
                img_filename = img_path.name
                txt_filename = img_path.stem + '.txt'
                
                output_txt = self.output_dir / txt_filename
                output_img = self.output_dir / img_filename
                
                if self.convert_json_to_yolov8_seg(json_path, img_path, output_txt):
                    shutil.copy(img_path, output_img)
        
        processed_count = len(file_pairs)
        print(f"Đã xử lý {processed_count} file")
        print(f"Kết quả được lưu vào {self.output_dir}")

def main():
    #input_dir = "/media/tat/Learn1/bai_toan/30_4/TaiNan_Training/tong"
    input_dir = '30_4/HungKHi_Training/tong'
    output_dir = "30_4/TaiNan_Training"
    # Bật chia dữ liệu, tỷ lệ train là 80%
    converter = SegToYOLOv8Converter(input_dir, output_dir, split_data=True, train_ratio=0.8)
    converter.process_dataset()

if __name__ == "__main__":
    main()