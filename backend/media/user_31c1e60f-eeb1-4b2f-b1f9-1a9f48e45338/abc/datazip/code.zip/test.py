import requests
import json

API_KEY = "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"

response = requests.post(
    url="https://openrouter.ai/api/v1/chat/completions",
    headers={
        "Authorization": f"Bearer {API_KEY}",
        "HTTP-Referer": "https://your-site.com",
        "X-Title": "YourSiteName", 
        "Content-Type": "application/json"
    },
    data=json.dumps({
        "model": "openai/o3-mini",
        "messages": [
        {
            "role": "system",
            "content": "Bạn là một trợ lý AI và bạn phải trả lời bằng tiếng Việt."
        },
        {
            "role": "user",
            "content": "Hố đen hoạt động như thế nào?"
        }
    ]
    })
)

# In kết quả
print(response.json())
