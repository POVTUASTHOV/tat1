import os
import zipfile
import random
import shutil
from pathlib import Path
import tempfile

def extract_images_from_zip(source_dir, destination_dir, images_per_zip=50):
    # Tạo thư mục đích nếu nó không tồn tại
    if not os.path.exists(destination_dir):
        os.makedirs(destination_dir)
    
    # Tìm tất cả các file ZIP trong thư mục nguồn
    zip_files = [os.path.join(source_dir, f) for f in os.listdir(source_dir) if f.endswith('.zip')]
    
    # Các định dạng ảnh thông dụng
    image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.webp']
    
    for zip_path in zip_files:
        zip_name = os.path.basename(zip_path)
        print(f"Đang xử lý file ZIP: {zip_name}")
        
        # Tạo thư mục tạm để giải nén
        with tempfile.TemporaryDirectory() as temp_dir:
            # Giải nén file ZIP
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Tìm tất cả các file ảnh trong thư mục giải nén (bao gồm các thư mục con)
            all_images = []
            for root, _, files in os.walk(temp_dir):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in image_extensions):
                        all_images.append(os.path.join(root, file))
            
            # Nếu không tìm thấy ảnh nào
            if not all_images:
                print(f"Không tìm thấy ảnh nào trong {zip_name}")
                continue
            
            # Chọn ngẫu nhiên số lượng ảnh cần thiết hoặc tất cả nếu ít hơn
            selected_images = random.sample(all_images, min(images_per_zip, len(all_images)))
            
            # Sao chép các ảnh đã chọn vào thư mục đích
            for img_path in selected_images:
                img_name = os.path.basename(img_path)
                # Tạo tên file duy nhất bằng cách thêm tên ZIP vào trước
                unique_name = f"{os.path.splitext(zip_name)[0]}_{img_name}"
                dest_path = os.path.join(destination_dir, unique_name)
                
                shutil.copy2(img_path, dest_path)
                print(f"  Đã sao chép: {img_name} -> {unique_name}")
            
            print(f"  Đã sao chép {len(selected_images)} ảnh từ {zip_name}")

if __name__ == "__main__":
    source_directory = r"D:\bai_toan\weapon\3_26\tong"
    destination_directory = r"D:\bai_toan\weapon\3_26\tong\tong_seg"
    
    extract_images_from_zip(source_directory, destination_directory, 50)
    print("Hoàn thành việc sao chép ảnh!")