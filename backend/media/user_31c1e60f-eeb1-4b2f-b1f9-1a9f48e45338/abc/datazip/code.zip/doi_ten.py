import os
import json
import glob

# Đường dẫn đến thư mục chứa các file JSON
directory_path = '30_4/HungKHi_Training/aug_xoay_gun'

json_files = glob.glob(os.path.join(directory_path, "*.json"))

# Biến để đếm số file đã được cập nhật
updated_files = 0

# Duyệt qua từng file JSON
for json_file in json_files:
    try:
        # Đọc nội dung file JSON
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Kiểm tra và cập nhật nhãn trong phần shapes
        modified = False
        for shape in data.get('shapes', []):
            if shape.get('label') == 'peerson':
                shape['label'] = 'person'
                modified = True
        
        # Nếu có thay đổi, ghi lại file JSON
        if modified:
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            print(f"Đã cập nhật file: {json_file}")
            updated_files += 1
        else:
            print(f"Không có nhãn 'non-accident' trong file: {json_file}")
            
    except Exception as e:
        print(f"Lỗi khi xử lý file {json_file}: {str(e)}")

# In tổng kết
print(f"\nĐã xử lý {len(json_files)} file JSON.")
print(f"Đã cập nhật {updated_files} file.")