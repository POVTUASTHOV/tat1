import os
import random
import shutil
from pathlib import Path

def copy_random_images(source_dir, destination_dir, images_count=100):
    if not os.path.exists(destination_dir):
        os.makedirs(destination_dir)
    
    image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.webp']
    
    all_images = []
    for root, _, files in os.walk(source_dir):
        for file in files:
            if any(file.lower().endswith(ext) for ext in image_extensions):
                all_images.append(os.path.join(root, file))
    
    if not all_images:
        print(f"Không tìm thấy ảnh nào trong {source_dir}")
        return
    
    folder_name = os.path.basename(source_dir)
    selected_images = random.sample(all_images, min(images_count, len(all_images)))
    
    for img_path in selected_images:
        img_name = os.path.basename(img_path)
        unique_name = f"{folder_name}_{img_name}"
        dest_path = os.path.join(destination_dir, unique_name)
        
        shutil.copy2(img_path, dest_path)
        print(f"Đã sao chép: {img_name} -> {unique_name}")
    
    print(f"Đã sao chép {len(selected_images)} ảnh từ {folder_name}")

if __name__ == "__main__":
    source_directory = r"D:\bai_toan\weapon\13_4\DJI_0380_W_2"
    destination_directory = r"D:\bai_toan\weapon\3_26\tong\tong_seg"
    
    copy_random_images(source_directory, destination_directory, 50)
    print("Hoàn thành việc sao chép ảnh!")