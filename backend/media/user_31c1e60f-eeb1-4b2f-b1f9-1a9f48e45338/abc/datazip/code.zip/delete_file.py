import os
import glob

def remove_files(directory_path, file_extension=".txt"):
    pattern = os.path.join(directory_path, f"*{file_extension}")
    files = glob.glob(pattern)
    total_files = len(files)
    deleted_count = 0
    error_count = 0
    error_files = []
    
    for file_path in files:
        try:
            os.remove(file_path)
            deleted_count += 1
        except Exception as e:
            error_count += 1
            error_files.append((file_path, str(e)))
            
        if deleted_count % 100 == 0 and deleted_count > 0:
            print(f"Deleted {deleted_count}/{total_files} files")
    
    print(f"Operation completed:")
    print(f"Files found: {total_files}")
    print(f"Files deleted: {deleted_count}")
    
    if error_count > 0:
        print(f"Errors encountered: {error_count}")
        for file_path, error in error_files[:5]:
            print(f"  - {os.path.basename(file_path)}: {error}")
        
        if len(error_files) > 5:
            print(f"  - ...and {len(error_files) - 5} more errors")

directory_path = "/media/tat/Learn1/bai_toan/Traffic/dro/a_xong/a"

file_extension = ".json"

remove_files(directory_path, file_extension)