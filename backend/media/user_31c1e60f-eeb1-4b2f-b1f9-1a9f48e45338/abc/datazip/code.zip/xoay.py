import json
import numpy as np
import cv2
import os
import random
from datetime import datetime
import copy
import glob

def load_labelme_json(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

def create_masks_from_polygon(shapes, image_height, image_width, label):
    masks = []
    polygon_indices = []
    for i, shape in enumerate(shapes):
        if shape['label'] == label:
            mask = np.zeros((image_height, image_width), dtype=np.uint8)
            points = shape['points']
            points_array = np.array(points, dtype=np.int32)
            cv2.fillPoly(mask, [points_array], 1)
            masks.append(mask)
            polygon_indices.append(i)
    return masks, polygon_indices

def find_overlap_center(stick_mask, person_masks):
    person_count = 0
    overlap_mask = None
    overlapping_person_idx = -1
    for i, person_mask in enumerate(person_masks):
        current_overlap = stick_mask & person_mask
        if np.any(current_overlap):
            person_count += 1
            overlapping_person_idx = i
            if overlap_mask is None:
                overlap_mask = current_overlap
            else:
                overlap_mask = overlap_mask | current_overlap
    if person_count != 1:
        return None, -1
    if overlap_mask is not None and np.any(overlap_mask):
        y_indices, x_indices = np.where(overlap_mask)
        center_y = np.mean(y_indices)
        center_x = np.mean(x_indices)
        return (center_x, center_y), overlapping_person_idx
    return None, -1

def create_mask_from_polygon(polygon, image_height, image_width):
    mask = np.zeros((image_height, image_width), dtype=np.uint8)
    points_array = np.array(polygon, dtype=np.int32)
    cv2.fillPoly(mask, [points_array], 1)
    return mask

def rotate_image_with_mask(image, mask, center, angle_deg):
    height, width = image.shape[:2]
    rotation_matrix = cv2.getRotationMatrix2D((center[0], center[1]), angle_deg, 1.0)
    rotated_img = cv2.warpAffine(image, rotation_matrix, (width, height), 
                               flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    rotated_mask = cv2.warpAffine(mask.astype(np.uint8), rotation_matrix, (width, height), 
                                flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT)
    return rotated_img, rotated_mask

def fill_region_with_surrounding(image, mask):
    mask = (mask > 0).astype(np.uint8)
    y_indices, x_indices = np.where(mask > 0)
    if len(y_indices) == 0:
        return image
    y_min, y_max = np.min(y_indices), np.max(y_indices)
    x_min, x_max = np.min(x_indices), np.max(x_indices)
    height, width = image.shape[:2]
    above_region_height = min(y_min, 30)
    below_region_height = min(height - y_max - 1, 30)
    sample_mask = np.zeros_like(mask)
    if above_region_height > 0:
        sample_mask[max(0, y_min - above_region_height):y_min, x_min:x_max + 1] = 1
    if below_region_height > 0:
        sample_mask[y_max + 1:y_max + 1 + below_region_height, x_min:x_max + 1] = 1
    if np.sum(sample_mask) == 0:
        inpaint_mask = mask * 255
        result_image = cv2.inpaint(image, inpaint_mask, inpaintRadius=3, flags=cv2.INPAINT_TELEA)
        return result_image
    sample_y, sample_x = np.where(sample_mask > 0)
    if len(sample_y) == 0:
        inpaint_mask = mask * 255
        result_image = cv2.inpaint(image, inpaint_mask, inpaintRadius=3, flags=cv2.INPAINT_TELEA)
        return result_image
    result_image = image.copy()
    mask_y, mask_x = np.where(mask > 0)
    num_pixels = len(mask_y)
    rand_indices = np.random.choice(len(sample_y), size=num_pixels, replace=True)
    sampled_y = sample_y[rand_indices]
    sampled_x = sample_x[rand_indices]
    result_image[mask_y, mask_x] = image[sampled_y, sampled_x]
    inpaint_mask = mask * 255
    result_image = cv2.inpaint(result_image, inpaint_mask, inpaintRadius=3, flags=cv2.INPAINT_TELEA)
    temp_mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)
    blurred = cv2.GaussianBlur(result_image, (5, 5), 0)
    result_image = np.where(temp_mask[:, :, np.newaxis] > 0, blurred, result_image)
    return result_image

def extract_stick_from_rotated_image(original_image, rotated_image, original_mask, rotated_mask):
    filled_image = fill_region_with_surrounding(original_image, original_mask)
    result_image = filled_image.copy()
    result_image[rotated_mask > 0] = rotated_image[rotated_mask > 0]
    return result_image

def get_stick_contour_from_mask(mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    largest_contour = max(contours, key=cv2.contourArea)
    epsilon = 0.001 * cv2.arcLength(largest_contour, True)
    approx_contour = cv2.approxPolyDP(largest_contour, epsilon, True)
    return [point[0].tolist() for point in approx_contour]

def generate_random_angles(num_angles=5, min_angle=5, max_angle=355):
    return sorted(random.sample(range(min_angle, max_angle), num_angles))

def save_image_and_json(image, json_data, output_dir, basename, angle):
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    new_filename = f"{basename}_rot{angle}_{timestamp}"
    image_path = os.path.join(output_dir, f"{new_filename}.jpg")
    cv2.imwrite(image_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
    json_data["imagePath"] = f"{new_filename}.jpg"
    json_data["imageData"] = None
    json_path = os.path.join(output_dir, f"{new_filename}.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(json_data, f, ensure_ascii=False, indent=2)
    return image_path, json_path

def process_image(image_path, json_path, output_dir, num_angles=5):
    try:
        labelme_data = load_labelme_json(json_path)
        img_bgr = cv2.imread(image_path)
        if img_bgr is None:
            raise FileNotFoundError(f"Cannot read image from {image_path}")
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        image_height, image_width = img_rgb.shape[:2]
        basename = os.path.splitext(os.path.basename(image_path))[0]
    except FileNotFoundError as e:
        print(f"Error: {e}")
        return
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return
    shapes = labelme_data.get('shapes', [])
    person_masks, person_indices = create_masks_from_polygon(shapes, image_height, image_width, "person")
    stick_masks, stick_indices = create_masks_from_polygon(shapes, image_height, image_width, "stick")
    if not stick_masks:
        print(f"No stick found in {image_path}")
        return
    valid_data = []
    for i, stick_mask in enumerate(stick_masks):
        center, person_idx = find_overlap_center(stick_mask, person_masks)
        if center and person_idx >= 0:
            stick_idx = stick_indices[i]
            valid_data.append((stick_mask, center, stick_idx))
    if not valid_data:
        print(f"No stick found overlapping with exactly one person in {image_path}")
        return
    angles = generate_random_angles(num_angles)
    print(f"Processing {image_path} with angles: {angles}")
    for angle in angles:
        new_json_data = copy.deepcopy(labelme_data)
        final_image = img_rgb.copy()
        filled_images = {}
        for stick_mask, center, stick_idx in valid_data:
            original_polygon = new_json_data["shapes"][stick_idx]["points"]
            filled_image = fill_region_with_surrounding(final_image, stick_mask)
            filled_images[stick_idx] = filled_image
            rotated_image, rotated_mask = rotate_image_with_mask(img_rgb, stick_mask, center, angle)
            final_image = filled_image.copy()
            final_image[rotated_mask > 0] = rotated_image[rotated_mask > 0]
            new_polygon = get_stick_contour_from_mask(rotated_mask)
            if new_polygon:
                new_json_data["shapes"][stick_idx]["points"] = new_polygon
            else:
                print(f"Could not generate new polygon from rotated mask for {image_path} at angle {angle}°")
                continue
        saved_image, saved_json = save_image_and_json(
            final_image, 
            new_json_data, 
            output_dir, 
            basename, 
            angle
        )
        print(f"Saved rotated image {angle}° at: {saved_image}")
        print(f"Saved JSON for {angle}° at: {saved_json}")

def main():
    input_dir = "/media/tat/Learn1/bai_toan/weapon/13_4/tong/0382"
    output_dir = "/media/tat/Learn1/bai_toan/weapon/13_4/tong/0380_1_xoay"
    num_angles = 5
    os.makedirs(output_dir, exist_ok=True)
    image_files = glob.glob(os.path.join(input_dir, "*.jpg")) + glob.glob(os.path.join(input_dir, "*.jpeg")) + glob.glob(os.path.join(input_dir, "*.png"))
    print(f"Found {len(image_files)} image files in {input_dir}")
    for image_path in image_files:
        json_path = os.path.splitext(image_path)[0] + ".json"
        if not os.path.exists(json_path):
            print(f"No JSON file found for {image_path}")
            continue
        print(f"\nProcessing: {image_path}")
        process_image(image_path, json_path, output_dir, num_angles)
    print(f"\nCompleted processing {len(image_files)} images.")

if __name__ == "__main__":
    main()