import os
import json

# Đường dẫn tới thư mục chứa file
folder_path = r"D:\bai_toan\weapon\3_26\tong\output_frames_20250327_102429\output_frames_20250327_102429"

# Tiền tố muốn thêm
prefix = "0356_"

# Duyệt qua tất cả các file trong thư mục
for filename in os.listdir(folder_path):
    # Đường dẫn đầy đủ tới file
    old_file_path = os.path.join(folder_path, filename)
    
    # Kiểm tra xem là file (không phải thư mục)
    if os.path.isfile(old_file_path):
        # Tạo tên file mới với tiền tố
        new_filename = prefix + filename
        new_file_path = os.path.join(folder_path, new_filename)
        
        # Đổi tên file
        os.rename(old_file_path, new_file_path)
        print(f"Đã đổi tên: {filename} -> {new_filename}")
        
        # Nếu file là JSON, cập nhật trường "imagePath"
        if new_filename.endswith(".json"):
            with open(new_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Lấy tên file ảnh cũ từ trường "imagePath"
            old_image_path = data.get("imagePath", "")
            if old_image_path:
                # Tạo tên file ảnh mới
                new_image_path = prefix + old_image_path
                # Cập nhật trường "imagePath"
                data["imagePath"] = new_image_path
            
            # Ghi lại file JSON
            with open(new_file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            print(f"Đã cập nhật imagePath trong {new_filename}: {old_image_path} -> {new_image_path}")

print("Hoàn tất!")