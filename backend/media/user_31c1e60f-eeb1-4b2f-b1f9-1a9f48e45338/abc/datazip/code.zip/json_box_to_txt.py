import os
import json
import shutil
from PIL import Image
from tqdm import tqdm

class LabelmeToYoloConverter:
    def __init__(self, input_dir, output_dir):
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.dataset_dir = os.path.join(output_dir, 'dataset')
        os.makedirs(self.dataset_dir, exist_ok=True)
        self.class_mapping = self.get_classes()

    def get_classes(self):
        classes = set()
        for filename in os.listdir(self.input_dir):
            if filename.endswith('.json'):
                with open(os.path.join(self.input_dir, filename), 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for shape in data.get('shapes', []):
                        label = shape.get('label', '').strip().lower()
                        if label:
                            classes.add(label)
        classes = sorted(classes)
        return {label: i for i, label in enumerate(classes)}

    def extract_box(self, points):
        if len(points) < 2:
            return None
        x_coords = [p[0] for p in points]
        y_coords = [p[1] for p in points]
        x_min, x_max = min(x_coords), max(x_coords)
        y_min, y_max = min(y_coords), max(y_coords)
        if abs(x_max - x_min) < 1 or abs(y_max - y_min) < 1:
            return None
        return x_min, y_min, x_max, y_max

    def convert_annotation(self, json_path, image_width, image_height):
        yolo_annotations = []
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for shape in data.get('shapes', []):
            label = shape.get('label', '').strip().lower()
            if label not in self.class_mapping:
                continue
            class_id = self.class_mapping[label]
            points = shape.get('points', [])
            box = self.extract_box(points)
            if not box:
                continue
            x_min, y_min, x_max, y_max = box
            x_center = (x_min + x_max) / 2 / image_width
            y_center = (y_min + y_max) / 2 / image_height
            width = (x_max - x_min) / image_width
            height = (y_max - y_min) / image_height
            yolo_annotations.append(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")
        return yolo_annotations

    def convert(self):
        image_exts = ['.jpg', '.jpeg', '.png']
        json_files = [f for f in os.listdir(self.input_dir) if f.endswith('.json')]
        for json_file in tqdm(json_files, desc='Processing'):
            base_name = os.path.splitext(json_file)[0]
            json_path = os.path.join(self.input_dir, json_file)
            image_path = None
            for ext in image_exts:
                temp_image = os.path.join(self.input_dir, base_name + ext)
                if os.path.exists(temp_image):
                    image_path = temp_image
                    break
            if not image_path:
                continue
            image = Image.open(image_path)
            width, height = image.size
            yolo_annots = self.convert_annotation(json_path, width, height)
            if not yolo_annots:
                continue
            shutil.copy(image_path, os.path.join(self.dataset_dir, os.path.basename(image_path)))
            label_output_path = os.path.join(self.dataset_dir, base_name + '.txt')
            with open(label_output_path, 'w') as f:
                f.write('\n'.join(yolo_annots))

if __name__ == '__main__':
    input_dir = r'D:\bai_toan\Traffic\them_du_lieu\q\box'
    output_dir = r'D:\bai_toan\Traffic\them_du_lieu\q\box_txt'
    converter = LabelmeToYoloConverter(input_dir, output_dir)
    converter.convert()
